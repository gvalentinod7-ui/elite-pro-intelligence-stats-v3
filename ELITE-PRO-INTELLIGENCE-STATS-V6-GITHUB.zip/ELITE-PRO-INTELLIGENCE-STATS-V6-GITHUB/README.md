# Élite-Pro Intelligence Universe 6.0 🌟🔥

Application Android native Jetpack Compose de divertissement statistique 5/90.

## V6 — Intelligence Universe

La V6 conserve la base stable Midnight Pearl et connecte six modules majeurs :

1. **Live Intelligence + Universe Brief** — synthèse de ce qui change après chaque tirage.
2. **Replay Lab Pro** — courbe de replays historiques calculés uniquement avec les données disponibles avant chaque cible.
3. **Championnat des moteurs** — classement Momentum, Cycle, Affinités, Jour, Retard et Historique, avec lecture globale et spécifique au jour cible.
4. **DNA 90** — fiche vivante de chaque numéro : fréquence, retard, lundi–samedi, positions N1–N5, compagnons, transitions et pulse récent.
5. **Galaxy des affinités** — réseau visuel combinant cooccurrences et transitions.
6. **Smart Generator Studio** — 7 profils : Consensus, Prudent, Dynamique, Contrarian, Jour, Affinités et Retards.

Sont également conservés : calendrier thermique, historique complet, vues lundi→samedi, numéros jamais sortis, Position Lab, Scenario Battle, matrice 1–90, import/export JSON/CSV, saisie depuis le calendrier et Elite AI.

## Base embarquée

180 tirages jusqu'au 10/08/2026. Les tirages ajoutés dans l'application sont conservés localement et tous les indicateurs sont recalculés.

## Android

- Package : `com.elitepro.intelligencestats.v6`
- Debug installable à côté des versions précédentes : `com.elitepro.intelligencestats.v6.dev`
- Version : 6.0.0
- minSdk 23
- targetSdk / compileSdk 36
- Kotlin + Jetpack Compose
- JDK 17

Les scénarios sont des outils de divertissement statistique et ne constituent pas des garanties de résultat.
