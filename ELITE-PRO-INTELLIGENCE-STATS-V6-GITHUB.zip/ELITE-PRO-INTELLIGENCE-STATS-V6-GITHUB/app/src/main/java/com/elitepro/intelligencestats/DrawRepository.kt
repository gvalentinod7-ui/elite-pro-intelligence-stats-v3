package com.elitepro.intelligencestats

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class DrawRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("elite_pro_stats", Context.MODE_PRIVATE)
    val draws = mutableStateListOf<Draw>()

    init { reload() }

    fun reload() {
        draws.clear()
        draws.addAll(loadBaseDraws())
        draws.addAll(loadUserDraws())
        draws.sortBy { it.date }
    }

    private fun loadBaseDraws(): List<Draw> {
        val raw = context.assets.open("draws.json").bufferedReader().use { it.readText() }
        return parseDrawArray(JSONArray(raw), "base")
    }

    private fun loadUserDraws(): List<Draw> {
        val raw = prefs.getString("user_draws", "[]") ?: "[]"
        return runCatching { parseDrawArray(JSONArray(raw), "user") }.getOrDefault(emptyList())
    }

    private fun parseDrawArray(array: JSONArray, fallbackSource: String): List<Draw> {
        val out = ArrayList<Draw>(array.length())
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            val nums = o.getJSONArray("numbers")
            val values = (0 until nums.length()).map { nums.getInt(it) }
            val date = o.getString("date")
            out += Draw(
                date = date,
                day = o.optString("day").ifBlank { dayFromDate(date) },
                numbers = values,
                source = o.optString("source", fallbackSource)
            )
        }
        return out
    }

    fun addDraw(draw: Draw): Result<Unit> {
        validateDraw(draw)?.let { return Result.failure(IllegalArgumentException(it)) }
        if (draws.any { it.date == draw.date }) return Result.failure(IllegalArgumentException("Un tirage existe déjà à cette date"))
        val user = loadUserDraws().toMutableList()
        user += draw.copy(source = "user")
        saveUserDraws(user)
        reload()
        return Result.success(Unit)
    }

    fun clearUserDraws() {
        prefs.edit().remove("user_draws").apply()
        reload()
    }

    fun exportJson(): String {
        val root = JSONObject()
        root.put("app", "Elite-Pro Ultimate Stats")
        root.put("format", "elite-pro-backup-v1")
        root.put("version", "6.0.0")
        root.put("exportedAt", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME))
        root.put("totalDraws", draws.size)
        root.put("draws", toJsonArray(draws))
        return root.toString(2)
    }

    fun exportCsv(): String = buildString {
        appendLine("date;day;n1;n2;n3;n4;n5;source")
        draws.forEach { d ->
            append(d.date).append(';')
            append(d.day).append(';')
            d.numbers.take(5).forEach { append(it).append(';') }
            appendLine(d.source)
        }
    }

    fun importText(raw: String): Result<Int> = runCatching {
        val trimmed = raw.trim()
        if (trimmed.isBlank()) error("Fichier vide")
        val imported = if (trimmed.startsWith("{") || trimmed.startsWith("[")) parseJsonImport(trimmed) else parseCsvImport(trimmed)
        mergeImported(imported)
    }

    private fun parseJsonImport(raw: String): List<Draw> {
        val array = if (raw.trimStart().startsWith("[")) JSONArray(raw) else {
            val root = JSONObject(raw)
            when {
                root.has("draws") -> root.getJSONArray("draws")
                root.has("userDraws") -> root.getJSONArray("userDraws")
                else -> error("JSON non reconnu : clé draws absente")
            }
        }
        return parseDrawArray(array, "import")
    }

    private fun parseCsvImport(raw: String): List<Draw> {
        val lines = raw.lineSequence().filter { it.isNotBlank() }.toList()
        if (lines.isEmpty()) return emptyList()
        val delimiter = if (lines.first().count { it == ';' } > lines.first().count { it == ',' }) ';' else ','
        val hasHeader = lines.first().lowercase().contains("date")
        return lines.drop(if (hasHeader) 1 else 0).mapIndexedNotNull { idx, line ->
            val parts = line.split(delimiter).map { it.trim().trim('"') }
            if (parts.size < 7) return@mapIndexedNotNull null
            val date = parts[0]
            val day = parts.getOrNull(1)?.ifBlank { dayFromDate(date) } ?: dayFromDate(date)
            val nums = parts.drop(2).take(5).mapNotNull { it.toIntOrNull() }
            if (nums.size != 5) error("CSV invalide à la ligne ${idx + 1}")
            Draw(date, day, nums, "import")
        }
    }

    private fun mergeImported(imported: List<Draw>): Int {
        val currentDates = draws.map { it.date }.toMutableSet()
        val existingUser = loadUserDraws().toMutableList()
        var added = 0
        imported.sortedBy { it.date }.forEach { draw ->
            validateDraw(draw)?.let { error("${draw.date}: $it") }
            if (draw.date !in currentDates) {
                existingUser += draw.copy(source = "user")
                currentDates += draw.date
                added++
            }
        }
        saveUserDraws(existingUser.distinctBy { it.date }.sortedBy { it.date })
        reload()
        return added
    }

    private fun validateDraw(draw: Draw): String? {
        if (runCatching { LocalDate.parse(draw.date) }.isFailure) return "Date invalide"
        if (draw.numbers.size != 5) return "5 numéros requis"
        if (draw.numbers.distinct().size != 5) return "Les numéros doivent être différents"
        if (draw.numbers.any { it !in 1..90 }) return "Les numéros doivent être entre 1 et 90"
        return null
    }

    private fun dayFromDate(date: String): String = runCatching {
        when (LocalDate.parse(date).dayOfWeek.value) {
            1 -> "lundi"; 2 -> "mardi"; 3 -> "mercredi"; 4 -> "jeudi"; 5 -> "vendredi"; 6 -> "samedi"; else -> "dimanche"
        }
    }.getOrDefault("")

    private fun toJsonArray(items: List<Draw>): JSONArray {
        val array = JSONArray()
        items.forEach { d ->
            val o = JSONObject()
            o.put("date", d.date)
            o.put("day", d.day)
            o.put("source", d.source)
            val nums = JSONArray()
            d.numbers.forEach { nums.put(it) }
            o.put("numbers", nums)
            array.put(o)
        }
        return array
    }

    private fun saveUserDraws(items: List<Draw>) {
        prefs.edit().putString("user_draws", toJsonArray(items.map { it.copy(source = "user") }).toString()).apply()
    }
}
