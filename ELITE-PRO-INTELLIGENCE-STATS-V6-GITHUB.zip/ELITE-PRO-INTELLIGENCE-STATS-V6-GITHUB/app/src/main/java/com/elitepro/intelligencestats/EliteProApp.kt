package com.elitepro.intelligencestats

import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// V6 Intelligence Universe — Midnight Pearl premium, living analytics universe.
private val Bg = Color(0xFF1D2A38)
private val BgTop = Color(0xFF26384A)
private val Surface = Color(0xFF2A3B4E)
private val Surface2 = Color(0xFF34495F)
private val Surface3 = Color(0xFF405A72)
private val Orange = Color(0xFFD6AA68)
private val Gold = Color(0xFFE7C98A)
private val Cyan = Color(0xFF8FD5DD)
private val Purple = Color(0xFFB8B7DE)
private val Pink = Color(0xFFD8ABC5)
private val Red = Color(0xFFE79A9A)
private val Green = Color(0xFF91D2B4)
private val Blue = Color(0xFF9EBEE7)
private val Text = Color(0xFFF7F3EB)
private val Muted = Color(0xFFC7D1DB)
private val Pearl = Color(0xFFF6F1E7)
private val Sand = Color(0xFFE0CDA6)
private val Ink = Color(0xFF24303D)

private enum class Tab(val title: String, val glyph: String) {
    HOME("Accueil", "⌂"),
    STUDIO("Studio", "⚡"),
    MATRIX("Matrice", "▦"),
    CALENDAR("Calendrier", "◫"),
    ASSISTANT("Elite AI", "AI")
}

@Composable
fun EliteProApp(context: Context) {
    val repository = remember { DrawRepository(context) }
    val draws = repository.draws
    var tab by remember { mutableStateOf(Tab.HOME) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold,
            secondary = Cyan,
            tertiary = Green,
            background = Bg,
            surface = Surface,
            onPrimary = Ink,
            onBackground = Text,
            onSurface = Text
        )
    ) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(BgTop, Bg, Color(0xFF182431)))
            )
        ) {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = { AppHeader(draws.size) },
            bottomBar = {
                NavigationBar(
                    modifier = Modifier.navigationBarsPadding(),
                    containerColor = Surface,
                    tonalElevation = 10.dp
                ) {
                    Tab.entries.forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = { Text(item.glyph, fontWeight = FontWeight.Black, fontSize = 16.sp) },
                            label = { Text(item.title, fontSize = 8.sp, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Gold,
                                selectedTextColor = Gold,
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted,
                                indicatorColor = Gold.copy(alpha = .14f)
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (tab) {
                    Tab.HOME -> HomeScreen(draws)
                    Tab.STUDIO -> StudioScreen(draws)
                    Tab.MATRIX -> MatrixScreen(draws)
                    Tab.CALENDAR -> CalendarHub(draws, repository, context)
                    Tab.ASSISTANT -> AssistantScreen(draws)
                }
            }
        }
        }
    }
}

@Composable
private fun AppHeader(drawCount: Int) {
    Surface(color = BgTop.copy(alpha = .96f)) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(46.dp)
                    .background(
                        Brush.linearGradient(listOf(Pearl, Sand, Blue.copy(alpha = .85f))),
                        RoundedCornerShape(16.dp)
                    )
                    .border(1.dp, Color.White.copy(alpha = .38f), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("EP", color = Ink, fontSize = 14.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text("Élite-Pro Intelligence Universe", color = Text, fontWeight = FontWeight.Black, fontSize = 15.sp)
                Text("Intelligence Universe 6.0 • $drawCount tirages", color = Muted, fontSize = 10.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                StatusPill("LIVE", Green)
                Spacer(Modifier.height(3.dp))
                Text("PREMIUM", color = Gold, fontSize = 7.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun HomeScreen(draws: List<Draw>) {
    val targetDay = remember(draws.size) { Analytics.nextTargetDay(draws) }
    val weights = remember(draws.size) { AdvancedAnalytics.adaptiveWeights(draws) }
    val consensus = remember(draws.size, targetDay) { AdvancedAnalytics.consensus(draws, targetDay, weights) }
    val regime = remember(draws.size) { AdvancedAnalytics.regime(draws) }
    val modelPerf = remember(draws.size) { AdvancedAnalytics.modelBacktest(draws, 32) }
    val last = draws.lastOrNull()
    val trend = remember(draws.size) { draws.takeLast(30).map { it.date.takeLast(5) to it.numbers.sum().toDouble() } }
    val hot = remember(draws.size) { Analytics.hot(draws, 8) }
    val liveAlerts = remember(draws.size) { SignatureAnalytics.liveAlerts(draws) }
    val universeBrief = remember(draws.size, targetDay) { UniverseAnalytics.brief(draws, targetDay) }
    var seed by remember { mutableIntStateOf(1) }
    val scenario = remember(draws.size, targetDay, seed) {
        AdvancedAnalytics.generateScenarios(draws, targetDay, 5, "Équilibré", 1, seed).firstOrNull()
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(13.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        HeroCard(targetDay, regime)
        DailyBrief(targetDay, consensus, regime, last)

        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            PremiumMetric("Tirages", draws.size.toString(), "BASE", Gold, Modifier.weight(1f))
            PremiumMetric("Régime", regime.label, "LIVE", Cyan, Modifier.weight(1f))
            PremiumMetric("Top", consensus.firstOrNull()?.number?.toString()?.padStart(2, '0') ?: "—", "CONSENSUS", Orange, Modifier.weight(1f))
        }

        GlassCard("Live Intelligence", "Signaux qui méritent ton attention maintenant", Green) {
            if (liveAlerts.isEmpty()) {
                Text("Aucun signal particulier pour le moment.", color = Muted, fontSize = 10.sp)
            } else {
                liveAlerts.forEach { alert ->
                    Row(
                        Modifier.fillMaxWidth()
                            .background(Surface2.copy(alpha = .72f), RoundedCornerShape(14.dp))
                            .border(1.dp, (if (alert.level >= 3) Gold else Cyan).copy(alpha = .18f), RoundedCornerShape(14.dp))
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(8.dp).background(
                                when (alert.level) { 3 -> Gold; 2 -> Cyan; else -> Green }, CircleShape
                            )
                        )
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text(alert.title, color = Text, fontSize = 10.sp, fontWeight = FontWeight.Black)
                            Text(alert.detail, color = Muted, fontSize = 9.sp, lineHeight = 12.sp)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                }
            }
        }

        GlassCard("Universe Brief", "Ce qui a changé et mérite un regard", Gold) {
            universeBrief.forEach { brief ->
                Row(
                    Modifier.fillMaxWidth().background(Surface2.copy(alpha = .70f), RoundedCornerShape(13.dp)).padding(9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(7.dp).background(if (brief.level >= 3) Gold else if (brief.level == 2) Cyan else Green, CircleShape))
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(brief.title, color = Text, fontSize = 9.sp, fontWeight = FontWeight.Black)
                        Text(brief.detail, color = Muted, fontSize = 8.sp, lineHeight = 11.sp)
                    }
                }
                Spacer(Modifier.height(5.dp))
            }
        }

        if (last != null) {
            GlassCard("Dernier tirage", "${last.date} • ${last.day.uppercase()}", Orange) {
                NumberBalls(last.numbers)
            }
        }

        GlassCard("Pulse graphique", "Somme des 30 derniers tirages", Cyan) {
            PremiumLineChart(trend, Cyan, Modifier.fillMaxWidth().height(165.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("30 tirages", color = Muted, fontSize = 9.sp)
                Text("min ${trend.minOfOrNull { it.second.toInt() } ?: 0} • max ${trend.maxOfOrNull { it.second.toInt() } ?: 0}", color = Gold, fontSize = 9.sp)
            }
        }

        GlassCard("Radar du leader", "6 facteurs • ${consensus.firstOrNull()?.number?.let { "numéro ${it.toString().padStart(2, '0')}" } ?: "—"}", Purple) {
            consensus.firstOrNull()?.let { leader ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadarChart(
                        listOf(leader.momentum, leader.cycle, leader.affinity, leader.day, leader.delay, leader.longTerm),
                        Modifier.size(190.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        MiniSignal("Momentum", leader.momentum, Orange)
                        MiniSignal("Cycle", leader.cycle, Gold)
                        MiniSignal("Affinités", leader.affinity, Purple)
                        MiniSignal("Jour", leader.day, Cyan)
                        MiniSignal("Retard", leader.delay, Red)
                        MiniSignal("Historique", leader.longTerm, Green)
                    }
                }
            }
        }

        GlassCard("Hot 8", "Fréquence sur les 20 derniers tirages", Orange) {
            PremiumBars(hot.map { it.number.toString().padStart(2, '0') to it.recent20.toDouble() }, Orange)
        }

        GlassCard("Conseil des modèles", "Performance historique récente", Gold) {
            PremiumBars(modelPerf.take(6).map { it.name to it.averageHits }, Gold, maxValue = max(1.0, modelPerf.maxOfOrNull { it.averageHits } ?: 1.0))
        }

        Button(
            onClick = { seed++ },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Orange),
            shape = RoundedCornerShape(20.dp)
        ) { Text("NOUVEAU SCÉNARIO", fontWeight = FontWeight.Black) }

        scenario?.let { ScenarioCard(it, 1) }

        Text(
            "Divertissement analytique : les scores comparent des motifs historiques et des backtests, sans garantir un résultat futur.",
            color = Muted,
            fontSize = 9.sp,
            lineHeight = 13.sp
        )
    }
}

@Composable
private fun DailyBrief(
    targetDay: String,
    consensus: List<ConsensusSignal>,
    regime: RegimeSnapshot,
    last: Draw?
) {
    Column(
        Modifier.fillMaxWidth()
            .background(
                Brush.horizontalGradient(listOf(Pearl.copy(alpha = .96f), Color(0xFFE9EEF4), Sand.copy(alpha = .90f))),
                RoundedCornerShape(22.dp)
            )
            .border(1.dp, Color.White.copy(alpha = .58f), RoundedCornerShape(22.dp))
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("BRIEF DU PROCHAIN TIRAGE", color = Ink.copy(alpha = .70f), fontSize = 7.sp, fontWeight = FontWeight.Black)
                Text(targetDay.uppercase(), color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Black)
                Text("${regime.label} • pulse ${regime.temperature}%", color = Color(0xFF506579), fontSize = 9.sp)
            }
            StatusPill("PEARL", Color(0xFF7A6440))
        }
        Spacer(Modifier.height(11.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Top consensus", color = Ink.copy(alpha = .66f), fontSize = 8.sp, modifier = Modifier.width(82.dp))
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.SpaceEvenly) {
                consensus.take(3).forEach { Ball(it.number, 39.dp) }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("Dernier", color = Ink.copy(alpha = .58f), fontSize = 7.sp)
                Text(last?.date?.takeLast(5) ?: "—", color = Ink, fontSize = 9.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun HeroCard(targetDay: String, regime: RegimeSnapshot) {
    Box(
        Modifier.fillMaxWidth()
            .background(
                Brush.linearGradient(
                    listOf(
                        Color(0xFF385069),
                        Color(0xFF30445A),
                        Color(0xFF2B3D51)
                    )
                ),
                RoundedCornerShape(28.dp)
            )
            .border(1.dp, Gold.copy(alpha = .30f), RoundedCornerShape(28.dp))
            .padding(20.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("INTELLIGENCE UNIVERSE 6.0", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.weight(1f))
                StatusPill("6 MODELS", Purple)
            }
            Text("Intelligence claire.\nPlaisir durable.", color = Text, fontSize = 30.sp, lineHeight = 33.sp, fontWeight = FontWeight.Black)
            Text(
                "Replay Lab Pro • Championnat • DNA 90 • Galaxy • Smart Generator • Live Intelligence",
                color = Muted,
                fontSize = 11.sp,
                lineHeight = 16.sp
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Prochaine cible  ", color = Muted, fontSize = 11.sp)
                Text(targetDay.uppercase(), color = Gold, fontWeight = FontWeight.Black)
                Spacer(Modifier.weight(1f))
                Text("${regime.temperature}% pulse", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun StudioScreen(draws: List<Draw>) {
    val days = listOf("lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi")
    var targetDay by remember(draws.size) { mutableStateOf(Analytics.nextTargetDay(draws)) }
    var size by remember { mutableIntStateOf(5) }
    var mode by remember { mutableStateOf("Équilibré") }
    var seed by remember { mutableIntStateOf(1) }
    val weights = remember(draws.size) { AdvancedAnalytics.adaptiveWeights(draws) }
    val consensus = remember(draws.size, targetDay) { AdvancedAnalytics.consensus(draws, targetDay, weights) }
    val modelPerf = remember(draws.size) { AdvancedAnalytics.modelBacktest(draws, 40) }
    val pairs = remember(draws.size) { AdvancedAnalytics.topPairs(draws, 60, 10) }
    val battle = remember(draws.size) { SignatureAnalytics.scenarioBattle(draws, 36) }
    val positions = remember(draws.size) { SignatureAnalytics.positionInsights(draws) }
    var selectedPosition by remember { mutableIntStateOf(1) }
    var replayOffset by remember { mutableIntStateOf(1) }
    val replay = remember(draws.size, replayOffset) { SignatureAnalytics.replay(draws, replayOffset) }
    val scenarios = remember(draws.size, targetDay, size, mode, seed) {
        AdvancedAnalytics.generateScenarios(draws, targetDay, size, mode, 3, seed)
    }
    val league = remember(draws.size, targetDay) { UniverseAnalytics.modelLeague(draws, targetDay, 60) }
    val replayTimeline = remember(draws.size) { UniverseAnalytics.replayTimeline(draws, 18) }
    var smartProfile by remember { mutableStateOf("Consensus") }
    val smartPick = remember(draws.size, targetDay, size, smartProfile, seed) {
        UniverseAnalytics.smartPick(draws, targetDay, size, smartProfile, seed)
    }
    var dnaNumber by remember(draws.size) { mutableIntStateOf(consensus.firstOrNull()?.number ?: 1) }
    val dna = remember(draws.size, dnaNumber) { UniverseAnalytics.dna(draws, dnaNumber) }
    val galaxy = remember(draws.size, dnaNumber) { UniverseAnalytics.galaxy(draws, dnaNumber, 10) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(13.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        PageTitle("Intelligence Universe", "6 modules connectés • laboratoire vivant • replays mesurables")

        GlassCard("Jour cible", "Le contexte temporel réoriente les modèles", Cyan) {
            ChoiceRow(days.map { it.take(3).uppercase() }, days.indexOf(targetDay).coerceAtLeast(0)) { targetDay = days[it] }
        }

        GlassCard("Championnat des moteurs", "Classement Universe • historique + spécial ${targetDay.uppercase()}", Gold) {
            if (league.isEmpty()) {
                Text("Pas assez de données pour le championnat.", color = Muted, fontSize = 10.sp)
            } else {
                PremiumBars(league.map { it.name to it.universeScore }, Gold, maxValue = 100.0)
                Spacer(Modifier.height(8.dp))
                league.forEachIndexed { index, entry ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        StatusPill("#${index + 1}", if (index == 0) Gold else Cyan)
                        Spacer(Modifier.width(7.dp))
                        Text(entry.name, color = Text, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text("${"%.2f".format(entry.dayHits)} jour", color = Cyan, fontSize = 8.sp)
                        Spacer(Modifier.width(8.dp))
                        Text("${"%.2f".format(entry.overallHits)} global", color = Muted, fontSize = 8.sp)
                    }
                }
            }
        }

        GlassCard("Mix adaptatif", "Poids auto-calibrés sur l'historique", Purple) {
            PremiumDonut(weights.asList(), Modifier.fillMaxWidth().height(185.dp))
            weights.asList().forEach { (name, value) -> SignalBar(name, value * 100, signalColor(name)) }
        }

        GlassCard("Backtest comparatif", "40 derniers tests sans regarder le tirage cible", Gold) {
            PremiumBars(modelPerf.map { it.name to it.averageHits }, Gold, maxValue = max(1.0, modelPerf.maxOfOrNull { it.averageHits } ?: 1.0))
            Spacer(Modifier.height(8.dp))
            modelPerf.take(6).forEach { p ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(p.name, color = Text, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.weight(1f))
                    Text("%.2f hit".format(p.averageHits), color = Gold, fontSize = 10.sp)
                    Spacer(Modifier.width(10.dp))
                    Text("%.0f%% ≥2".format(p.atLeast2Rate * 100), color = Cyan, fontSize = 10.sp)
                }
            }
        }

        GlassCard("Scenario Battle", "Les 3 styles s'affrontent sur 36 replays historiques", Pink) {
            if (battle.isEmpty()) {
                Text("Pas assez de données pour la bataille.", color = Muted, fontSize = 10.sp)
            } else {
                PremiumBars(battle.map { it.mode to it.averageHits }, Pink, maxValue = max(1.0, battle.maxOfOrNull { it.averageHits } ?: 1.0))
                Spacer(Modifier.height(8.dp))
                battle.forEachIndexed { index, b ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        StatusPill(if (index == 0) "#1" else "#${index + 1}", if (index == 0) Gold else Cyan)
                        Spacer(Modifier.width(8.dp))
                        Text(b.mode, color = Text, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text("%.2f hit".format(b.averageHits), color = Gold, fontSize = 9.sp)
                        Spacer(Modifier.width(8.dp))
                        Text("%.0f%% ≥2".format(b.atLeast2Rate * 100), color = Cyan, fontSize = 9.sp)
                    }
                }
            }
        }

        GlassCard("Replay Lab Pro", "Courbe de vérité • aucun regard sur le résultat futur", Purple) {
            if (replayTimeline.isNotEmpty()) {
                PremiumLineChart(replayTimeline.map { it.date.takeLast(5) to it.hits.toDouble() }, Purple, Modifier.fillMaxWidth().height(150.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${replayTimeline.size} replays", color = Muted, fontSize = 8.sp)
                    Text("moy. ${"%.2f".format(replayTimeline.map { it.hits }.average())}/5", color = Gold, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    Text("best ${replayTimeline.maxOfOrNull { it.hits } ?: 0}/5", color = Cyan, fontSize = 8.sp)
                }
                Spacer(Modifier.height(10.dp))
            }
            Text("Choisis combien de tirages remonter", color = Muted, fontSize = 9.sp)
            val offsets = listOf(1, 2, 3, 5, 10)
            ChoiceRow(offsets.map { "-$it" }, offsets.indexOf(replayOffset).coerceAtLeast(0)) { replayOffset = offsets[it] }
            Spacer(Modifier.height(10.dp))
            replay?.let { r ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(r.target.date, color = Text, fontSize = 15.sp, fontWeight = FontWeight.Black)
                        Text("${r.target.day.uppercase()} • état calculé avec ${r.historySize} tirages antérieurs", color = Muted, fontSize = 8.sp)
                    }
                    StatusPill("REPLAY", Purple)
                }
                Spacer(Modifier.height(9.dp))
                Text("Résultat réel", color = Muted, fontSize = 8.sp)
                NumberBalls(r.target.numbers)
                Spacer(Modifier.height(9.dp))
                ReplayRow("Consensus", r.consensusTop5, r.consensusHits, Cyan)
                ReplayRow("Prudent", r.prudent, r.prudentHits, Gold)
                ReplayRow("Équilibré", r.balanced, r.balancedHits, Green)
                ReplayRow("Explorateur", r.explorer, r.explorerHits, Pink)
            }
        }

        GlassCard("Position Lab N1–N5", "Le comportement change selon l'ordre de sortie", Cyan) {
            ChoiceRow(listOf("N1", "N2", "N3", "N4", "N5"), selectedPosition - 1) { selectedPosition = it + 1 }
            val pos = positions.getOrNull(selectedPosition - 1)
            pos?.let { insight ->
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    PremiumMetric("Leader récent", insight.recentLeader?.toString()?.padStart(2, '0') ?: "—", "30 TIRAGES", Cyan, Modifier.weight(1f))
                    PremiumMetric("Présences", insight.recentLeaderCount.toString(), "EN N${insight.position}", Gold, Modifier.weight(1f))
                    PremiumMetric("Jamais", insight.never.size.toString(), "EN N${insight.position}", Purple, Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                PremiumBars(insight.top.take(8).map { it.first.toString().padStart(2, '0') to it.second.toDouble() }, Cyan)
                if (insight.never.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text("Jamais sortis en N${insight.position}", color = Muted, fontSize = 8.sp)
                    TagRow(insight.never.take(24).map { it.toString().padStart(2, '0') })
                    if (insight.never.size > 24) Text("+ ${insight.never.size - 24} autres", color = Purple, fontSize = 8.sp)
                }
            }
        }

        GlassCard("DNA 90", "Carte d'identité vivante d'un numéro", Cyan) {
            val dnaChoices = consensus.take(6).map { it.number }
            if (dnaChoices.isNotEmpty()) {
                Text("Explorer les leaders actuels", color = Muted, fontSize = 8.sp)
                ChoiceRow(dnaChoices.map { it.toString().padStart(2, '0') }, dnaChoices.indexOf(dnaNumber).coerceAtLeast(0)) { dnaNumber = dnaChoices[it] }
                Spacer(Modifier.height(10.dp))
            }
            dna?.let { d ->
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    PremiumMetric("Numéro", d.number.toString().padStart(2, '0'), "DNA", Gold, Modifier.weight(1f))
                    PremiumMetric("Fréquence", d.frequency.toString(), "TOTAL", Green, Modifier.weight(1f))
                    PremiumMetric("Retard", d.currentDelay.toString(), "TIRAGES", Purple, Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Text("Empreinte lundi → samedi", color = Muted, fontSize = 8.sp)
                PremiumBars(d.dayCounts.map { it.first to it.second.toDouble() }, Cyan)
                Spacer(Modifier.height(10.dp))
                Text("Positions N1 → N5", color = Muted, fontSize = 8.sp)
                PremiumBars(d.positionCounts.map { it.first to it.second.toDouble() }, Gold)
                Spacer(Modifier.height(10.dp))
                Text("Pulse 36 derniers tirages", color = Muted, fontSize = 8.sp)
                PremiumLineChart(d.pulse, Green, Modifier.fillMaxWidth().height(115.dp))
            }
        }

        GlassCard("Galaxy des affinités", "Réseau compagnon + transition du numéro ${dnaNumber.toString().padStart(2, '0')}", Purple) {
            AffinityGalaxy(dnaNumber, galaxy, Modifier.fillMaxWidth().height(235.dp))
            if (galaxy.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                TagRow(galaxy.map { "${it.number.toString().padStart(2,'0')} · ${"%.0f".format(it.strength)}" })
            }
        }

        GlassCard("Smart Generator Studio", "7 philosophies • une explication claire", Green) {
            Text("Taille", color = Muted, fontSize = 8.sp)
            ChoiceRow(listOf("2", "3", "5"), listOf(2, 3, 5).indexOf(size)) { size = listOf(2, 3, 5)[it] }
            Spacer(Modifier.height(8.dp))
            val p1 = listOf("Consensus", "Prudent", "Dynamique", "Contrarian")
            val p2 = listOf("Jour", "Affinités", "Retards")
            Text("Profil Universe", color = Muted, fontSize = 8.sp)
            ChoiceRow(p1, p1.indexOf(smartProfile)) { smartProfile = p1[it] }
            Spacer(Modifier.height(5.dp))
            ChoiceRow(p2, p2.indexOf(smartProfile)) { smartProfile = p2[it] }
            Spacer(Modifier.height(10.dp))
            Button(onClick = { seed++ }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                Text("NOUVELLE PROPOSITION", color = Ink, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.height(10.dp))
            NumberBalls(smartPick.numbers)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(smartPick.profile.uppercase(), color = Gold, fontSize = 9.sp, fontWeight = FontWeight.Black)
                Text("confiance analytique ${"%.0f".format(smartPick.confidence)}", color = Cyan, fontSize = 9.sp)
            }
            Text(smartPick.rationale, color = Muted, fontSize = 9.sp, lineHeight = 13.sp)
        }

        GlassCard("Générateur 3 scénarios", "Prudent • équilibré • explorateur", Orange) {
            Text("Taille", color = Muted, fontSize = 9.sp)
            ChoiceRow(listOf("2", "3", "5"), listOf(2, 3, 5).indexOf(size)) { size = listOf(2, 3, 5)[it] }
            Spacer(Modifier.height(8.dp))
            Text("Style", color = Muted, fontSize = 9.sp)
            val modes = listOf("Prudent", "Équilibré", "Explorateur")
            ChoiceRow(modes, modes.indexOf(mode)) { mode = modes[it] }
            Spacer(Modifier.height(10.dp))
            Button(onClick = { seed++ }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Orange)) {
                Text("GÉNÉRER", fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.height(10.dp))
            scenarios.forEachIndexed { i, scenario ->
                ScenarioCard(scenario, i + 1)
                if (i < scenarios.lastIndex) Spacer(Modifier.height(8.dp))
            }
        }

        GlassCard("Consensus Top 12", "Votes et score composite", Cyan) {
            consensus.take(12).forEachIndexed { index, signal -> ConsensusRow(index + 1, signal) }
        }

        GlassCard("Paires sous tension", "Associations récentes vs historique", Pink) {
            pairs.forEach { p ->
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Ball(p.first, 31.dp); Text(" + ", color = Muted); Ball(p.second, 31.dp)
                    Spacer(Modifier.weight(1f))
                    Text("${p.recent} récent", color = Pink, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Text("${p.total} total", color = Muted, fontSize = 9.sp)
                }
            }
        }
    }
}

@Composable
private fun MatrixScreen(draws: List<Draw>) {
    var selected by remember { mutableIntStateOf(1) }
    var mode by remember { mutableStateOf("Consensus") }
    val targetDay = remember(draws.size) { Analytics.nextTargetDay(draws) }
    val consensus = remember(draws.size, targetDay) { AdvancedAnalytics.consensus(draws, targetDay) }
    val map = remember(consensus) { consensus.associateBy { it.number } }
    val signal = map[selected]
    val companions = remember(draws.size, selected) { Analytics.bestCompanions(draws, selected, 8) }
    val transitions = remember(draws.size, selected) { AdvancedAnalytics.transitions(draws, selected, 8) }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PageTitle("Matrice Midnight 1–90", "Lecture par intensité • touchez un numéro pour ouvrir sa fiche ADN")
        val modes = listOf("Consensus", "Momentum", "Retard", "Jour")
        ChoiceRow(modes, modes.indexOf(mode)) { mode = modes[it] }
        MatrixLegend()

        LazyVerticalGrid(
            columns = GridCells.Fixed(10),
            modifier = Modifier.fillMaxWidth().height(302.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            gridItems((1..90).toList()) { n ->
                val s = map[n]
                val value = when (mode) {
                    "Momentum" -> s?.momentum ?: 0.0
                    "Retard" -> s?.delay ?: 0.0
                    "Jour" -> s?.day ?: 0.0
                    else -> s?.consensus ?: 0.0
                }
                val c = heatColor(value)
                val isSelected = selected == n
                Box(
                    Modifier.aspectRatio(1f)
                        .background(
                            if (isSelected) {
                                Brush.linearGradient(listOf(Pearl, Sand))
                            } else {
                                Brush.verticalGradient(listOf(c.copy(alpha = .22f), Surface2.copy(alpha = .95f)))
                            },
                            RoundedCornerShape(10.dp)
                        )
                        .border(
                            if (isSelected) 2.dp else 1.dp,
                            if (isSelected) Gold else c.copy(alpha = .34f),
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { selected = n },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        n.toString().padStart(2, '0'),
                        color = if (isSelected) Ink else Text,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }

        signal?.let { s ->
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    GlassCard("Fiche ADN • ${selected.toString().padStart(2, '0')}", "${s.votes}/6 modèles en soutien • cible ${targetDay.uppercase()}", Gold) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Ball(selected, 62.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Score composite", color = Muted, fontSize = 8.sp)
                                Text("%.0f / 100".format(s.consensus), color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Black)
                                Text(
                                    when {
                                        s.consensus >= 75 -> "Signal très soutenu"
                                        s.consensus >= 60 -> "Signal soutenu"
                                        s.consensus >= 45 -> "Signal intermédiaire"
                                        else -> "Signal discret"
                                    },
                                    color = if (s.consensus >= 60) Green else Cyan,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            StatusPill("${s.votes}/6", if (s.votes >= 4) Green else Cyan)
                        }
                        Spacer(Modifier.height(11.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            PremiumMetric("Retard", s.stat.currentDelay.toString(), "TIRAGES", Purple, Modifier.weight(1f))
                            PremiumMetric("20 récents", s.stat.recent20.toString(), "SORTIES", Cyan, Modifier.weight(1f))
                            PremiumMetric("Fréquence", s.stat.frequency.toString(), "TOTAL", Green, Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(12.dp))
                        SignalBar("Momentum", s.momentum, Orange)
                        SignalBar("Cycle", s.cycle, Gold)
                        SignalBar("Affinités", s.affinity, Purple)
                        SignalBar("Profil jour", s.day, Cyan)
                        SignalBar("Retard", s.delay, Red)
                        SignalBar("Historique", s.longTerm, Green)
                    }
                }
                item {
                    GlassCard("Connexions", "Compagnons historiques et transitions observées", Cyan) {
                        Text("COMPAGNONS", color = Gold, fontSize = 8.sp, fontWeight = FontWeight.Black)
                        Spacer(Modifier.height(5.dp))
                        TagRow(companions.map { "${it.first.toString().padStart(2, '0')} · ${it.second}x" })
                        Spacer(Modifier.height(10.dp))
                        Text("TRANSITIONS", color = Cyan, fontSize = 8.sp, fontWeight = FontWeight.Black)
                        Spacer(Modifier.height(5.dp))
                        TagRow(transitions.map { "${it.to.toString().padStart(2, '0')} · ${it.count}x" })
                    }
                }
            }
        }
    }
}

@Composable
private fun CalendarHub(draws: List<Draw>, repository: DrawRepository, context: Context) {
    var section by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp)) {
        PageTitle("Calendrier & Data Vault", "Mémoire visuelle, historique lundi–samedi, JSON/CSV")
        ChoiceRow(listOf("CALENDRIER", "HISTORIQUE", "JOURS", "DATA"), section) { section = it }
        Spacer(Modifier.height(9.dp))
        when (section) {
            0 -> CalendarScreen(draws, repository)
            1 -> HistoryScreen(draws, repository)
            2 -> DayHistoryScreen(draws)
            else -> DataVault(draws, repository, context)
        }
    }
}

@Composable
private fun CalendarScreen(draws: List<Draw>, repository: DrawRepository) {
    val lastDate = remember(draws.size) { draws.lastOrNull()?.let { runCatching { LocalDate.parse(it.date) }.getOrNull() } ?: LocalDate.now() }
    var month by remember { mutableStateOf(YearMonth.from(lastDate)) }
    var selected by remember { mutableStateOf<Draw?>(draws.lastOrNull()) }
    var addDate by remember { mutableStateOf<LocalDate?>(null) }
    val drawByDate = remember(draws.size) { draws.associateBy { it.date } }
    val monthDraws = remember(draws.size, month) { draws.filter { runCatching { YearMonth.from(LocalDate.parse(it.date)) == month }.getOrDefault(false) } }
    val sums = monthDraws.map { it.numbers.sum().toDouble() }
    val avg = sums.averageOrZero()
    val monthLabel = month.month.getDisplayName(TextStyle.FULL, Locale.FRENCH).replaceFirstChar { it.uppercase() } + " ${month.year}"

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        GlassCard("Calendrier thermique", monthLabel, Cyan) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SmallAction("‹") { month = month.minusMonths(1) }
                Spacer(Modifier.weight(1f))
                Text(monthLabel.uppercase(), color = Text, fontWeight = FontWeight.Black, fontSize = 14.sp)
                Spacer(Modifier.weight(1f))
                SmallAction("›") { month = month.plusMonths(1) }
            }
            Spacer(Modifier.height(9.dp))
            Row(Modifier.fillMaxWidth()) {
                listOf("L", "M", "M", "J", "V", "S", "D").forEach { d -> Text(d, color = Muted, fontSize = 9.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f)) }
            }
            Spacer(Modifier.height(5.dp))
            val first = month.atDay(1)
            val prefix = first.dayOfWeek.value - 1
            val cells: List<LocalDate?> = List(prefix) { null } + (1..month.lengthOfMonth()).map { month.atDay(it) }
            LazyVerticalGrid(
                columns = GridCells.Fixed(7),
                modifier = Modifier.fillMaxWidth().height(300.dp),
                userScrollEnabled = false,
                verticalArrangement = Arrangement.spacedBy(5.dp),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                gridItems(cells) { date ->
                    if (date == null) Spacer(Modifier.aspectRatio(1f))
                    else {
                        val d = drawByDate[date.toString()]
                        val sum = d?.numbers?.sum() ?: 0
                        val intensity = if (d == null) 0.0 else ((sum - 100.0) / 280.0 * 100.0).coerceIn(10.0, 100.0)
                        CalendarCell(date.dayOfMonth, d, intensity, selected?.date == d?.date) {
                            if (d != null) selected = d else addDate = date
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("● tirage", color = Cyan, fontSize = 8.sp)
                Text("intensité = somme", color = Muted, fontSize = 8.sp)
                Text("${monthDraws.size} tirages", color = Gold, fontSize = 8.sp)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            PremiumMetric("Tirages", monthDraws.size.toString(), "MOIS", Gold, Modifier.weight(1f))
            PremiumMetric("Somme moy.", if (sums.isEmpty()) "—" else "%.0f".format(avg), "MOIS", Cyan, Modifier.weight(1f))
            PremiumMetric("Max", sums.maxOrNull()?.toInt()?.toString() ?: "—", "SOMME", Orange, Modifier.weight(1f))
        }

        if (monthDraws.isNotEmpty()) {
            GlassCard("Courbe du mois", "Évolution de la somme par tirage", Purple) {
                PremiumLineChart(monthDraws.map { it.date.takeLast(2) to it.numbers.sum().toDouble() }, Purple, Modifier.fillMaxWidth().height(155.dp))
            }
        }

        GlassCard("Ajout express", "Touche une date vide du calendrier pour saisir directement le tirage", Green) {
            Text("Les dates déjà occupées ouvrent le tirage. Les dates vides ouvrent la saisie avec la date préremplie.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
        }

        selected?.let { d ->
            GlassCard("Focus ${d.date}", d.day.uppercase(), Orange) {
                NumberBalls(d.numbers)
                Spacer(Modifier.height(9.dp))
                val fp = AdvancedAnalytics.fingerprint(draws, draws.indexOf(d))
                fp?.let {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PremiumMetric("Somme", it.sum.toString(), "Σ", Gold, Modifier.weight(1f))
                        PremiumMetric("Pair", it.even.toString(), "5", Cyan, Modifier.weight(1f))
                        PremiumMetric("Répét.", it.repeatsFromPrevious.toString(), "↺", Purple, Modifier.weight(1f))
                        PremiumMetric("Étendue", it.spread.toString(), "Δ", Green, Modifier.weight(1f))
                    }
                }
            }
        }
    }

    addDate?.let { dateToAdd ->
        AddDrawDialog(dateToAdd, repository, onDismiss = { addDate = null }) { result ->
            if (result) addDate = null
        }
    }
}

@Composable
private fun HistoryScreen(draws: List<Draw>, repository: DrawRepository) {
    var date by remember { mutableStateOf(LocalDate.now().format(DateTimeFormatter.ISO_DATE)) }
    var nums by remember { mutableStateOf(List(5) { "" }) }
    var message by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    val filtered = remember(draws.size, search) {
        if (search.isBlank()) draws.asReversed()
        else draws.asReversed().filter { d ->
            search in d.date || search.lowercase() in d.day.lowercase() || d.numbers.any { it.toString() == search.trim() }
        }
    }

    Column(Modifier.fillMaxSize()) {
        GlassCard("Nouveau tirage", "Ajout instantané + recalcul complet", Orange) {
            OutlinedTextField(value = date, onValueChange = { date = it }, label = { Text("Date AAAA-MM-JJ") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(7.dp))
            PremiumNumberInputs(nums) { index, value ->
                nums = nums.toMutableList().also { it[index] = value }
            }
            Spacer(Modifier.height(7.dp))
            Button(
                onClick = {
                    val parsed = nums.mapNotNull { it.toIntOrNull() }
                    val localDate = runCatching { LocalDate.parse(date) }.getOrNull()
                    if (localDate == null) message = "Date invalide."
                    else if (parsed.size != 5) message = "Saisis les 5 numéros."
                    else {
                        val day = dayName(localDate)
                        val result = repository.addDraw(Draw(date, day, parsed, "user"))
                        message = result.fold(
                            onSuccess = { nums = List(5) { "" }; "Ajout réussi : moteur 5.3 recalculé." },
                            onFailure = { it.message ?: "Erreur" }
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Orange)
            ) { Text("AJOUTER & RÉAPPRENDRE", fontWeight = FontWeight.Black) }
            if (message.isNotBlank()) { Spacer(Modifier.height(6.dp)); Text(message, color = if ("réussi" in message) Green else Red, fontSize = 10.sp) }
        }

        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            placeholder = { Text("Rechercher date, jour ou numéro") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${filtered.size} tirage(s) affiché(s)", color = Gold, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Text("Historique complet", color = Muted, fontSize = 9.sp)
        }
        Spacer(Modifier.height(7.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(filtered, key = { it.date }) { d ->
                Row(
                    Modifier.fillMaxWidth().background(Surface, RoundedCornerShape(15.dp)).border(1.dp, Color.White.copy(alpha = .04f), RoundedCornerShape(15.dp)).padding(9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.width(82.dp)) {
                        Text(d.date, color = Text, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(d.day, color = Muted, fontSize = 8.sp)
                        Text("Σ${d.numbers.sum()}", color = Gold, fontSize = 8.sp)
                    }
                    Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(3.dp)) { d.numbers.forEach { Ball(it, 29.dp) } }
                    if (d.source == "user") StatusPill("NEW", Green)
                }
            }
        }
    }
}


@Composable
private fun DayHistoryScreen(draws: List<Draw>) {
    val days = listOf("lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi")
    var selectedDay by remember { mutableStateOf("lundi") }
    val dayDraws = remember(draws.size, selectedDay) {
        draws.filter { it.day.equals(selectedDay, true) }.asReversed()
    }
    val frequencies = remember(draws.size, selectedDay) {
        IntArray(91).also { freq ->
            dayDraws.forEach { d -> d.numbers.forEach { n -> if (n in 1..90) freq[n]++ } }
        }
    }
    val never = remember(draws.size, selectedDay) { (1..90).filter { frequencies[it] == 0 } }
    val top10 = remember(draws.size, selectedDay) {
        (1..90).map { it to frequencies[it] }
            .sortedWith(compareByDescending<Pair<Int, Int>> { it.second }.thenBy { it.first })
            .take(10)
    }
    val delayTop = remember(draws.size, selectedDay) {
        (1..90).mapNotNull { n ->
            val delay = dayDraws.indexOfFirst { n in it.numbers }
            if (delay >= 0) n to delay else null
        }.sortedByDescending { it.second }.take(8)
    }
    val dominantPairs = remember(draws.size, selectedDay) {
        val counts = mutableMapOf<Pair<Int, Int>, Int>()
        dayDraws.forEach { d ->
            val ns = d.numbers.sorted()
            for (i in 0 until ns.size) {
                for (j in i + 1 until ns.size) {
                    val key = ns[i] to ns[j]
                    counts[key] = (counts[key] ?: 0) + 1
                }
            }
        }
        counts.entries.sortedByDescending { it.value }.take(8)
    }
    val positionLeaders = remember(draws.size, selectedDay) {
        (0..4).map { pos ->
            val counts = mutableMapOf<Int, Int>()
            dayDraws.forEach { d ->
                d.numbers.getOrNull(pos)?.let { n -> counts[n] = (counts[n] ?: 0) + 1 }
            }
            val leader = counts.maxByOrNull { it.value }
            if (leader == null) "N${pos + 1}: —" else "N${pos + 1}: ${leader.key.toString().padStart(2, '0')} · ${leader.value}x"
        }
    }
    val trend = remember(draws.size, selectedDay) {
        dayDraws.asReversed().takeLast(24).map { it.date.takeLast(5) to it.numbers.sum().toDouble() }
    }
    val globalFreq = remember(draws.size) {
        IntArray(91).also { freq ->
            draws.forEach { d -> d.numbers.forEach { n -> if (n in 1..90) freq[n]++ } }
        }
    }
    val globalTop = remember(draws.size) {
        (1..90).map { it to globalFreq[it] }
            .sortedWith(compareByDescending<Pair<Int, Int>> { it.second }.thenBy { it.first })
            .take(10)
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            days.forEach { day ->
                FilterChip(
                    selected = selectedDay == day,
                    onClick = { selectedDay = day },
                    label = { Text(day.uppercase(), fontSize = 8.sp, fontWeight = FontWeight.Black) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Gold.copy(alpha = .18f),
                        selectedLabelColor = Gold,
                        containerColor = Surface2,
                        labelColor = Muted
                    )
                )
            }
        }
        Spacer(Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            PremiumMetric("Tirages", dayDraws.size.toString(), selectedDay.uppercase(), Gold, Modifier.weight(1f))
            PremiumMetric("Jamais sortis", never.size.toString(), "1–90", Red, Modifier.weight(1f))
            PremiumMetric("Top", top10.firstOrNull()?.first?.toString()?.padStart(2, '0') ?: "—", "DU JOUR", Cyan, Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))

        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            item {
                GlassCard("TOP 10 • ${selectedDay.uppercase()}", "Les numéros les plus présents ce jour", Gold) {
                    if (top10.isEmpty()) Text("Aucune donnée", color = Muted)
                    else PremiumBars(top10.map { it.first.toString().padStart(2, '0') to it.second.toDouble() }, Gold)
                }
            }

            item {
                GlassCard("Jamais sortis • ${selectedDay.uppercase()}", "Numéros 1–90 absents de l'historique de ce jour", Red) {
                    if (never.isEmpty()) {
                        Text("Tous les numéros 1–90 sont déjà apparus au moins une fois ce jour.", color = Green, fontSize = 10.sp)
                    } else {
                        TagRow(never.map { it.toString().padStart(2, '0') })
                        Spacer(Modifier.height(6.dp))
                        Text("${never.size} numéro(s) encore jamais sorti(s) le $selectedDay.", color = Muted, fontSize = 9.sp)
                    }
                }
            }

            item {
                GlassCard("Retards extrêmes", "Nombre de tirages de ce jour depuis la dernière apparition", Purple) {
                    if (delayTop.isEmpty()) Text("Pas assez de données.", color = Muted)
                    else PremiumBars(delayTop.map { it.first.toString().padStart(2, '0') to it.second.toDouble() }, Purple)
                }
            }

            item {
                GlassCard("Paires dominantes", "Associations les plus fréquentes sur les ${dayDraws.size} ${selectedDay}s", Cyan) {
                    if (dominantPairs.isEmpty()) Text("Pas assez de données.", color = Muted)
                    else {
                        dominantPairs.chunked(2).forEach { row ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                row.forEach { entry ->
                                    Row(
                                        Modifier.weight(1f)
                                            .background(Surface, RoundedCornerShape(14.dp))
                                            .border(1.dp, Cyan.copy(alpha = .16f), RoundedCornerShape(14.dp))
                                            .padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Ball(entry.key.first, 30.dp)
                                        Text(" + ", color = Muted, fontSize = 9.sp)
                                        Ball(entry.key.second, 30.dp)
                                        Spacer(Modifier.weight(1f))
                                        Text("${entry.value}x", color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Black)
                                    }
                                }
                                if (row.size == 1) Spacer(Modifier.weight(1f))
                            }
                            Spacer(Modifier.height(6.dp))
                        }
                    }
                }
            }

            if (trend.isNotEmpty()) {
                item {
                    GlassCard("Évolution du ${selectedDay}", "Somme des 24 derniers tirages de ce jour", Blue) {
                        PremiumLineChart(trend, Blue, Modifier.fillMaxWidth().height(160.dp))
                    }
                }
            }

            item {
                GlassCard("Leaders par position", "Numéro le plus fréquent en N1, N2, N3, N4 et N5", Green) {
                    TagRow(positionLeaders)
                }
            }

            item {
                GlassCard("TOP GLOBAL", "Référence sur tous les tirages", Cyan) {
                    PremiumBars(globalTop.map { it.first.toString().padStart(2, '0') to it.second.toDouble() }, Cyan)
                }
            }

            item {
                Text(
                    "HISTORIQUE ${selectedDay.uppercase()} • ${dayDraws.size} TIRAGES",
                    color = Gold,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Black
                )
            }

            items(dayDraws, key = { it.date }) { d ->
                Row(
                    Modifier.fillMaxWidth()
                        .background(Surface, RoundedCornerShape(17.dp))
                        .border(1.dp, Color.White.copy(alpha = .07f), RoundedCornerShape(17.dp))
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.width(82.dp)) {
                        Text(d.date, color = Text, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text("Σ${d.numbers.sum()}", color = Gold, fontSize = 8.sp)
                    }
                    Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        d.numbers.forEach { Ball(it, 29.dp) }
                    }
                    if (d.source == "user") StatusPill("NEW", Green)
                }
            }
        }
    }
}

@Composable
private fun AddDrawDialog(
    date: LocalDate,
    repository: DrawRepository,
    onDismiss: () -> Unit,
    onSaved: (Boolean) -> Unit
) {
    var nums by remember(date) { mutableStateOf(List(5) { "" }) }
    var message by remember(date) { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Surface2,
        shape = RoundedCornerShape(24.dp),
        titleContentColor = Text,
        textContentColor = Text,
        title = {
            Column {
                Text("Nouveau tirage", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Black)
                Text(
                    date.format(DateTimeFormatter.ofPattern("EEEE d MMMM yyyy", Locale.FRENCH)).replaceFirstChar { it.uppercase() },
                    color = Text, fontSize = 18.sp, fontWeight = FontWeight.Black
                )
                Text("Saisie directe depuis le calendrier", color = Cyan, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "5 numéros • 1–90 • doublons bloqués",
                    color = Muted,
                    fontSize = 9.sp,
                    lineHeight = 12.sp
                )
                PremiumNumberInputs(nums) { index, value ->
                    nums = nums.toMutableList().also { it[index] = value }
                    message = ""
                }
                if (message.isNotBlank()) {
                    Box(
                        Modifier.fillMaxWidth()
                            .background(Red.copy(alpha = .12f), RoundedCornerShape(12.dp))
                            .padding(9.dp)
                    ) {
                        Text(message, color = Red, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val parsed = nums.mapNotNull { it.toIntOrNull() }
                    when {
                        parsed.size != 5 -> message = "Saisis les 5 numéros."
                        parsed.any { it !in 1..90 } -> message = "Chaque numéro doit être entre 1 et 90."
                        parsed.distinct().size != 5 -> message = "Les 5 numéros doivent être différents."
                        else -> {
                            val result = repository.addDraw(Draw(date.toString(), dayName(date), parsed, "user"))
                            result.onSuccess { onSaved(true) }.onFailure { message = it.message ?: "Erreur" }
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text("VALIDER & RÉAPPRENDRE", fontWeight = FontWeight.Black, fontSize = 10.sp)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("ANNULER", color = Muted, fontWeight = FontWeight.Bold)
            }
        }
    )
}


@Composable
private fun PremiumNumberInputs(
    values: List<String>,
    onChange: (Int, String) -> Unit
) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        values.forEachIndexed { index, value ->
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("N${index + 1}", color = Muted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                OutlinedTextField(
                    value = value,
                    onValueChange = { onChange(index, it.filter(Char::isDigit).take(2)) },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    singleLine = true,
                    placeholder = {
                        Text(
                            "—",
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center,
                            color = Muted.copy(alpha = .55f)
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        color = Text,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    shape = RoundedCornerShape(20.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Gold,
                        unfocusedBorderColor = Blue.copy(alpha = .30f),
                        focusedContainerColor = Surface3,
                        unfocusedContainerColor = Surface,
                        cursorColor = Gold
                    )
                )
            }
        }
    }
}

@Composable
private fun DataVault(draws: List<Draw>, repository: DrawRepository, context: Context) {
    var message by remember { mutableStateOf("Prêt. Tes données restent locales jusqu'à ce que tu exportes un fichier.") }
    var showReset by remember { mutableStateOf(false) }
    val userCount = draws.count { it.source == "user" }

    val exportJson = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(repository.exportJson()) } }
                .onSuccess { message = "✅ Sauvegarde JSON créée." }
                .onFailure { message = "❌ Export JSON : ${it.message}" }
        }
    }
    val exportCsv = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(repository.exportCsv()) } }
                .onSuccess { message = "✅ Export CSV créé." }
                .onFailure { message = "❌ Export CSV : ${it.message}" }
        }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("Lecture impossible")
                repository.importText(raw).getOrThrow()
            }
                .onSuccess { count -> message = if (count == 0) "ℹ️ Aucun nouveau tirage : doublons ignorés." else "✅ Import réussi : $count nouveau(x) tirage(s)." }
                .onFailure { message = "❌ Import : ${it.message}" }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        GlassCard("Data Vault", "Backup portable • JSON + CSV • fusion anti-doublons", Green) {
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                PremiumMetric("Total", draws.size.toString(), "TIRAGES", Gold, Modifier.weight(1f))
                PremiumMetric("Base", (draws.size - userCount).toString(), "EMBARQUÉS", Cyan, Modifier.weight(1f))
                PremiumMetric("Ajoutés", userCount.toString(), "PERSO", Green, Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            Text(message, color = if (message.startsWith("❌")) Red else if (message.startsWith("✅")) Green else Muted, fontSize = 10.sp, lineHeight = 14.sp)
        }

        GlassCard("Exporter", "Crée une copie que tu peux conserver, partager ou ouvrir dans Excel", Cyan) {
            DataAction("JSON", "Sauvegarde complète", "Base + tirages ajoutés + métadonnées", Purple) {
                exportJson.launch("elite-pro-backup-${LocalDate.now()}.json")
            }
            Spacer(Modifier.height(7.dp))
            DataAction("CSV", "Export tableur", "date, jour, 5 numéros, source", Green) {
                exportCsv.launch("elite-pro-tirages-${LocalDate.now()}.csv")
            }
        }

        GlassCard("Importer", "JSON ou CSV • les dates déjà présentes sont ignorées", Orange) {
            DataAction("IMPORT", "Restaurer / fusionner", "Sélectionne un .json ou .csv depuis ton téléphone", Orange) {
                importer.launch(arrayOf("application/json", "text/csv", "text/plain", "application/octet-stream"))
            }
        }

        GlassCard("Sécurité locale", "Pas de permission de stockage générale", Gold) {
            Text("Le sélecteur de fichiers Android gère l'accès document par document. L'application n'explore pas le stockage du téléphone.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
            if (userCount > 0) {
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { showReset = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("EFFACER UNIQUEMENT LES TIRAGES AJOUTÉS", color = Red, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                }
            }
        }
    }

    if (showReset) {
        AlertDialog(
            onDismissRequest = { showReset = false },
            title = { Text("Réinitialiser les ajouts ?") },
            text = { Text("La base embarquée restera intacte. Seuls les tirages ajoutés/importés seront supprimés.") },
            confirmButton = {
                TextButton(onClick = { repository.clearUserDraws(); showReset = false; message = "Tirages ajoutés supprimés. Base embarquée conservée." }) { Text("CONFIRMER", color = Red) }
            },
            dismissButton = { TextButton(onClick = { showReset = false }) { Text("ANNULER") } }
        )
    }
}

@Composable
private fun AssistantScreen(draws: List<Draw>) {
    data class ChatLine(val user: Boolean, val text: String)
    var query by remember { mutableStateOf("") }
    val chat = remember { mutableStateListOf(ChatLine(false, "Elite AI 5.3 prêt. Je peux lire le consensus, les cycles, les jours, les transitions, les retards et les backtests de la base locale.")) }
    val prompts = listOf("Top lundi", "Jamais sortis samedi", "Consensus lundi", "Backtest modèles", "Transitions 26", "Top retards")

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        PageTitle("Elite AI 5.3", "Assistant analytique local • réponses ancrées dans la base")
        Spacer(Modifier.height(6.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(chat) { line -> ChatBubble(line.user, line.text) }
        }
        Column(Modifier.fillMaxWidth().background(Surface, RoundedCornerShape(18.dp)).padding(10.dp)) {
            Text("Raccourcis", color = Muted, fontSize = 8.sp)
            Spacer(Modifier.height(5.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                prompts.forEach { p ->
                    AssistChip(onClick = { chat += ChatLine(true, p); chat += ChatLine(false, AssistantEngine.answer(p, draws)) }, label = { Text(p, fontSize = 8.sp) })
                }
            }
            Spacer(Modifier.height(7.dp))
            OutlinedTextField(value = query, onValueChange = { query = it }, placeholder = { Text("Ex. analyse 27, profil samedi…") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(7.dp))
            Button(
                onClick = {
                    if (query.isNotBlank()) {
                        val q = query
                        chat += ChatLine(true, q)
                        chat += ChatLine(false, AssistantEngine.answer(q, draws))
                        query = ""
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Orange)
            ) { Text("DEMANDER À ELITE AI", fontWeight = FontWeight.Black) }
        }
    }
}

@Composable
private fun CalendarCell(day: Int, draw: Draw?, intensity: Double, selected: Boolean, onClick: () -> Unit) {
    val accent = if (draw == null) Surface3 else heatColor(intensity)
    Box(
        Modifier.aspectRatio(1f)
            .background(if (draw == null) Surface2 else accent.copy(alpha = .19f), RoundedCornerShape(10.dp))
            .border(if (selected) 2.dp else 1.dp, if (selected) Gold else accent.copy(alpha = if (draw == null) .12f else .5f), RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(day.toString(), color = if (draw == null) Muted.copy(alpha = .55f) else Text, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            if (draw != null) {
                Spacer(Modifier.height(2.dp))
                Box(Modifier.size(5.dp).background(if (draw.source == "user") Green else accent, CircleShape))
            }
        }
    }
}

@Composable
private fun DataAction(tag: String, title: String, subtitle: String, accent: Color, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Surface2, RoundedCornerShape(15.dp)).clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(45.dp).background(accent.copy(alpha = .15f), RoundedCornerShape(13.dp)).border(1.dp, accent.copy(alpha = .35f), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
            Text(tag, color = accent, fontSize = if (tag.length > 4) 8.sp else 10.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Text, fontWeight = FontWeight.Black, fontSize = 12.sp)
            Text(subtitle, color = Muted, fontSize = 9.sp)
        }
        Text("›", color = accent, fontSize = 24.sp, fontWeight = FontWeight.Light)
    }
}

@Composable
private fun PremiumLineChart(data: List<Pair<String, Double>>, accent: Color, modifier: Modifier = Modifier) {
    if (data.size < 2) { Box(modifier, contentAlignment = Alignment.Center) { Text("Pas assez de données", color = Muted, fontSize = 10.sp) }; return }
    val minV = data.minOf { it.second }
    val maxV = data.maxOf { it.second }
    val range = max(1.0, maxV - minV)
    Canvas(modifier.padding(horizontal = 4.dp, vertical = 6.dp)) {
        val w = size.width
        val h = size.height
        repeat(4) { i ->
            val y = h * i / 3f
            drawLine(Color.White.copy(alpha = .06f), Offset(0f, y), Offset(w, y), strokeWidth = 1f)
        }
        val points = data.mapIndexed { i, pair ->
            val x = i.toFloat() / (data.lastIndex.coerceAtLeast(1)) * w
            val y = h - (((pair.second - minV) / range).toFloat() * (h * .78f) + h * .08f)
            Offset(x, y)
        }
        val fill = Path().apply {
            moveTo(points.first().x, h)
            points.forEach { lineTo(it.x, it.y) }
            lineTo(points.last().x, h)
            close()
        }
        drawPath(fill, brush = Brush.verticalGradient(listOf(accent.copy(alpha = .28f), Color.Transparent)))
        val path = Path().apply { moveTo(points.first().x, points.first().y); points.drop(1).forEach { lineTo(it.x, it.y) } }
        drawPath(path, color = accent, style = Stroke(width = 4f, cap = StrokeCap.Round))
        points.takeLast(8).forEach { drawCircle(accent, radius = 3.5f, center = it) }
    }
}

@Composable
private fun PremiumBars(data: List<Pair<String, Double>>, accent: Color, maxValue: Double = max(1.0, data.maxOfOrNull { it.second } ?: 1.0)) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        data.forEach { (label, value) ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(label, color = Text, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(68.dp), maxLines = 1)
                Box(Modifier.weight(1f).height(8.dp).background(Surface3, CircleShape)) {
                    Box(Modifier.fillMaxWidth((value / maxValue).toFloat().coerceIn(.02f, 1f)).fillMaxHeight().background(Brush.horizontalGradient(listOf(accent.copy(alpha = .55f), accent)), CircleShape))
                }
                Spacer(Modifier.width(8.dp))
                Text(if (value % 1.0 == 0.0) value.toInt().toString() else "%.2f".format(value), color = accent, fontSize = 9.sp, fontWeight = FontWeight.Black, modifier = Modifier.width(32.dp), textAlign = TextAlign.End)
            }
        }
    }
}

@Composable
private fun AffinityGalaxy(centerNumber: Int, nodes: List<UniverseAnalytics.GalaxyNode>, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Canvas(Modifier.fillMaxWidth().weight(1f)) {
            val c = Offset(size.width / 2f, size.height / 2f)
            val radius = min(size.width, size.height) * .34f
            val count = max(1, nodes.size)
            nodes.forEachIndexed { index, node ->
                val angle = (-PI / 2.0 + index * (2.0 * PI / count)).toFloat()
                val satellite = Offset(
                    c.x + cos(angle) * radius,
                    c.y + sin(angle) * radius
                )
                val alpha = (.18f + (node.strength / 100.0 * .62).toFloat()).coerceIn(.18f, .8f)
                val color = when {
                    node.strength >= 75 -> Gold
                    node.strength >= 55 -> Cyan
                    node.strength >= 35 -> Green
                    else -> Purple
                }
                drawLine(color.copy(alpha = alpha), c, satellite, strokeWidth = 2f + (node.strength / 100.0 * 4.0).toFloat())
                drawCircle(color.copy(alpha = .18f), radius = 18f + (node.strength / 100.0 * 16.0).toFloat(), center = satellite)
                drawCircle(color, radius = 7f + (node.strength / 100.0 * 7.0).toFloat(), center = satellite)
            }
            drawCircle(Gold.copy(alpha = .16f), radius = 42f, center = c)
            drawCircle(Gold, radius = 17f, center = c)
        }
        Text("centre ${centerNumber.toString().padStart(2, '0')} • force = compagnon + transition", color = Muted, fontSize = 8.sp)
    }
}

@Composable
private fun PremiumDonut(weights: List<Pair<String, Double>>, modifier: Modifier = Modifier) {
    val colors = listOf(Orange, Gold, Purple, Cyan, Red, Green)
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.size(160.dp)) {
            val stroke = 24f
            val canvasSize = size
            var start = -90f
            weights.forEachIndexed { index, (_, value) ->
                val sweep = (value * 360f).toFloat()
                drawArc(colors[index % colors.size], start, sweep - 2f, false, topLeft = Offset(stroke, stroke), size = Size(canvasSize.width - stroke * 2, canvasSize.height - stroke * 2), style = Stroke(stroke, cap = StrokeCap.Round))
                start += sweep
            }
        }
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            weights.forEachIndexed { i, (name, value) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(7.dp).background(colors[i % colors.size], CircleShape))
                    Spacer(Modifier.width(6.dp))
                    Text(name, color = Muted, fontSize = 9.sp, modifier = Modifier.weight(1f))
                    Text("%.0f%%".format(value * 100), color = Text, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun RadarChart(values: List<Double>, modifier: Modifier = Modifier) {
    val colors = listOf(Orange, Gold, Purple, Cyan, Red, Green)
    Canvas(modifier.padding(12.dp)) {
        val center = Offset(size.width / 2, size.height / 2)
        val radius = min(size.width, size.height) * .43f
        val count = values.size.coerceAtLeast(3)
        fun point(index: Int, factor: Float): Offset {
            val angle = -PI / 2 + 2 * PI * index / count
            return Offset(center.x + cos(angle).toFloat() * radius * factor, center.y + sin(angle).toFloat() * radius * factor)
        }
        for (level in 1..4) {
            val factor = level / 4f
            val p = Path().apply {
                val first = point(0, factor); moveTo(first.x, first.y)
                for (i in 1 until count) { val q = point(i, factor); lineTo(q.x, q.y) }
                close()
            }
            drawPath(p, Color.White.copy(alpha = .08f), style = Stroke(1f))
        }
        for (i in 0 until count) drawLine(Color.White.copy(alpha = .08f), center, point(i, 1f), 1f)
        val shape = Path().apply {
            val first = point(0, (values[0] / 100).toFloat().coerceIn(0f, 1f)); moveTo(first.x, first.y)
            for (i in 1 until count) { val q = point(i, (values[i] / 100).toFloat().coerceIn(0f, 1f)); lineTo(q.x, q.y) }
            close()
        }
        drawPath(shape, brush = Brush.radialGradient(listOf(Orange.copy(alpha = .42f), Purple.copy(alpha = .15f))))
        drawPath(shape, color = Gold, style = Stroke(3f, cap = StrokeCap.Round))
        values.forEachIndexed { i, value -> drawCircle(colors[i % colors.size], 4.5f, point(i, (value / 100).toFloat().coerceIn(0f, 1f))) }
    }
}

@Composable
private fun MatrixLegend() {
    Row(
        Modifier.fillMaxWidth()
            .background(Surface.copy(alpha = .72f), RoundedCornerShape(14.dp))
            .border(1.dp, Color.White.copy(alpha = .08f), RoundedCornerShape(14.dp))
            .padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        listOf(
            "Discret" to Purple,
            "Stable" to Blue,
            "Actif" to Green,
            "Fort" to Cyan,
            "Élite" to Gold
        ).forEach { (label, color) ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).background(color, CircleShape))
                Spacer(Modifier.width(3.dp))
                Text(label, color = Muted, fontSize = 6.sp)
            }
        }
    }
}

@Composable
private fun GlassCard(title: String, subtitle: String? = null, accent: Color = Orange, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth()
            .background(
                Brush.linearGradient(listOf(Surface2.copy(alpha = .98f), Surface, BgTop.copy(alpha = .96f))),
                RoundedCornerShape(21.dp)
            )
            .border(1.dp, accent.copy(alpha = .22f), RoundedCornerShape(21.dp))
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(4.dp).height(25.dp).background(accent, CircleShape))
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Text, fontWeight = FontWeight.Black, fontSize = 14.sp)
                if (subtitle != null) Text(subtitle, color = Muted, fontSize = 8.sp)
            }
        }
        Spacer(Modifier.height(11.dp))
        content()
    }
}

@Composable
private fun PremiumMetric(label: String, value: String, hint: String, accent: Color, modifier: Modifier = Modifier) {
    Column(
        modifier.background(Brush.verticalGradient(listOf(accent.copy(alpha = .13f), Surface2.copy(alpha = .88f))), RoundedCornerShape(15.dp))
            .border(1.dp, accent.copy(alpha = .14f), RoundedCornerShape(15.dp)).padding(horizontal = 7.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, color = accent, fontSize = 18.sp, fontWeight = FontWeight.Black, maxLines = 1)
        Text(label, color = Text, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(hint, color = Muted, fontSize = 6.sp, maxLines = 1)
    }
}

@Composable
private fun PageTitle(title: String, subtitle: String) {
    Column {
        Text(title, color = Text, fontSize = 24.sp, fontWeight = FontWeight.Black)
        Text(subtitle, color = Muted, fontSize = 9.sp)
    }
}

@Composable
private fun MiniSignal(name: String, value: Double, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(name.take(4), color = Muted, fontSize = 7.sp, modifier = Modifier.width(28.dp))
        LinearProgressIndicator(progress = { (value / 100).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.weight(1f).height(5.dp), color = color, trackColor = Surface3)
        Text("%.0f".format(value), color = color, fontSize = 7.sp, modifier = Modifier.width(24.dp), textAlign = TextAlign.End)
    }
}

@Composable
private fun ReplayRow(label: String, numbers: List<Int>, hits: Int, accent: Color) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp)
            .background(Surface.copy(alpha = .78f), RoundedCornerShape(14.dp))
            .border(1.dp, accent.copy(alpha = .16f), RoundedCornerShape(14.dp))
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Text, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(70.dp))
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            numbers.take(5).forEach { Ball(it, 26.dp) }
        }
        StatusPill("$hits/5", if (hits >= 2) Green else accent)
    }
}

@Composable
private fun ScenarioCard(s: ScenarioPack, index: Int) {
    Column(
        Modifier.fillMaxWidth().background(Surface2, RoundedCornerShape(17.dp))
            .border(1.dp, Orange.copy(alpha = .16f), RoundedCornerShape(17.dp)).padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("SCÉNARIO $index", color = Gold, fontSize = 8.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.weight(1f))
            StatusPill(s.label.uppercase(), if (s.stability >= 60) Green else Cyan)
        }
        Spacer(Modifier.height(9.dp))
        NumberBalls(s.numbers)
        Spacer(Modifier.height(9.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PremiumMetric("Consensus", "%.0f".format(s.score), "SCORE", Orange, Modifier.weight(1f))
            PremiumMetric("Stabilité", "%.0f%%".format(s.stability), "INDEX", Green, Modifier.weight(1f))
            PremiumMetric("Diversité", "%.0f%%".format(s.diversity), "INDEX", Purple, Modifier.weight(1f))
        }
    }
}

@Composable
private fun ConsensusRow(rank: Int, s: ConsensusSignal) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("#$rank", color = Muted, modifier = Modifier.width(27.dp), fontSize = 8.sp)
        Ball(s.number, 32.dp)
        Spacer(Modifier.width(7.dp))
        Column(Modifier.weight(1f)) {
            LinearProgressIndicator(progress = { (s.consensus / 100).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(6.dp), color = heatColor(s.consensus), trackColor = Surface3)
            Spacer(Modifier.height(2.dp))
            Text("${s.votes}/6 modèles · M${"%.0f".format(s.momentum)} C${"%.0f".format(s.cycle)} J${"%.0f".format(s.day)}", color = Muted, fontSize = 7.sp)
        }
        Spacer(Modifier.width(6.dp))
        Text("%.0f".format(s.consensus), color = Gold, fontWeight = FontWeight.Black, fontSize = 11.sp)
    }
}

@Composable
private fun ChatBubble(user: Boolean, text: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
        Column(
            Modifier.fillMaxWidth(.89f)
                .background(if (user) Orange.copy(alpha = .17f) else Surface, RoundedCornerShape(16.dp))
                .border(1.dp, if (user) Orange.copy(alpha = .32f) else Cyan.copy(alpha = .08f), RoundedCornerShape(16.dp))
                .padding(11.dp)
        ) {
            Text(if (user) "TOI" else "ELITE AI", color = if (user) Gold else Cyan, fontSize = 7.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(4.dp))
            Text(text, color = Text, fontSize = 11.sp, lineHeight = 17.sp)
        }
    }
}

@Composable
private fun NumberBalls(numbers: List<Int>) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) { numbers.forEach { Ball(it, 44.dp) } }
}

@Composable
private fun Ball(number: Int, size: androidx.compose.ui.unit.Dp) {
    Box(
        Modifier.size(size)
            .background(
                Brush.linearGradient(
                    listOf(
                        Color.White.copy(alpha = .98f),
                        Pearl,
                        Sand.copy(alpha = .82f),
                        Blue.copy(alpha = .22f)
                    )
                ),
                CircleShape
            )
            .border(1.dp, Gold.copy(alpha = .50f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            number.toString().padStart(2, '0'),
            color = Ink,
            fontWeight = FontWeight.Black,
            fontSize = if (size >= 40.dp) 13.sp else 9.sp
        )
    }
}

@Composable
private fun SignalBar(name: String, value: Double, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(name, color = Muted, fontSize = 8.sp, modifier = Modifier.width(66.dp))
        LinearProgressIndicator(progress = { (value / 100).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.weight(1f).height(6.dp), color = color, trackColor = Surface3)
        Text("%.0f".format(value), color = Text, fontSize = 8.sp, modifier = Modifier.width(28.dp), textAlign = TextAlign.End)
    }
}

@Composable
private fun StatusPill(label: String, color: Color) {
    Box(Modifier.background(color.copy(alpha = .13f), CircleShape).border(1.dp, color.copy(alpha = .32f), CircleShape).padding(horizontal = 8.dp, vertical = 4.dp)) {
        Text(label, color = color, fontSize = 7.sp, fontWeight = FontWeight.Black, maxLines = 1)
    }
}

@Composable
private fun TagRow(tags: List<String>) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        tags.forEach { tag ->
            Box(Modifier.background(Surface2, CircleShape).border(1.dp, Color.White.copy(alpha = .05f), CircleShape).padding(horizontal = 8.dp, vertical = 5.dp)) {
                Text(tag, color = Text, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ChoiceRow(labels: List<String>, selected: Int, onSelected: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        labels.forEachIndexed { index, label ->
            Box(
                Modifier.weight(1f)
                    .background(if (selected == index) Orange.copy(alpha = .17f) else Surface2, RoundedCornerShape(10.dp))
                    .border(1.dp, if (selected == index) Orange.copy(alpha = .48f) else Color.White.copy(alpha = .04f), RoundedCornerShape(10.dp))
                    .clickable { onSelected(index) }.padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) { Text(label, color = if (selected == index) Gold else Muted, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1) }
        }
    }
}

@Composable
private fun SmallAction(label: String, onClick: () -> Unit) {
    Box(Modifier.size(34.dp).background(Surface2, CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(label, color = Gold, fontSize = 22.sp)
    }
}

private fun heatColor(value: Double): Color = when {
    value >= 78 -> Gold
    value >= 64 -> Cyan
    value >= 50 -> Green
    value >= 36 -> Blue
    else -> Purple
}

private fun signalColor(name: String): Color = when (name) {
    "Momentum" -> Orange
    "Cycle" -> Gold
    "Affinités" -> Purple
    "Jour" -> Cyan
    "Retard" -> Red
    else -> Green
}

private fun List<Double>.averageOrZero(): Double = if (isEmpty()) 0.0 else average()

private fun dayName(date: LocalDate): String = when (date.dayOfWeek.value) {
    1 -> "lundi"; 2 -> "mardi"; 3 -> "mercredi"; 4 -> "jeudi"; 5 -> "vendredi"; 6 -> "samedi"; else -> "dimanche"
}
