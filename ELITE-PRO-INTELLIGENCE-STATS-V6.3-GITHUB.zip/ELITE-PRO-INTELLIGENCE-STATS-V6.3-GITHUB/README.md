# Élite-Pro Time & Motion 6.3 ✨

Version expérimentale installable à côté de V6.2.

## Nouveautés V6.3

- Horloge locale vivante à la seconde dans l'en-tête.
- Time Center : heure, date française, jour cible statistique, taille de la base et dernier tirage.
- Showtime 5/90 : animation séquentielle de cinq boules nacrées.
- Profils Showtime : Consensus, Prudent, Dynamique, Contrarian et Jour.
- Les boules finales viennent du Smart Generator statistique ; l'animation intermédiaire reste purement visuelle.
- Motion Rhythm : courbe des sommes sur les 30 derniers tirages + Pulse Focus.
- Animations volontairement confinées à l'espace MOTION pour préserver le confort visuel.
- Matrice Fluide, Pulse Studio, Chrono Universe, calendrier, historique, JSON/CSV, DNA 90, Galaxy, Replay et Elite AI conservés.

## Android

- applicationId : `com.elitepro.intelligencestats.v63`
- versionCode : 630
- versionName : 6.3.0
- minSdk : 23
- targetSdk / compileSdk : 36

## Compilation GitHub

Le workflow génère l'artifact :

`ELITE-PRO-TIME-MOTION-V6.3-FIRE`

contenant :

`ELITE-PRO-TIME-MOTION-V6.3-FIRE.apk`
