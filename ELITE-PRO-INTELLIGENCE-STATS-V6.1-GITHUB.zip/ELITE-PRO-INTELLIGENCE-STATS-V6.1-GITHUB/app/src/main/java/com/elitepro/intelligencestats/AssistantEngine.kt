package com.elitepro.intelligencestats

object AssistantEngine {
    fun answer(query: String, draws: List<Draw>): String {
        val q = query.trim().lowercase()
        if (q.isBlank()) return "Demande-moi : « chrono », « simulation », « brief », « championnat mardi », « DNA 27 », « galaxy 42 », « smart dynamique 5 », « replay », « position N3 », « consensus » ou « live »."

        val number = Regex("""\b([1-9]|[1-8][0-9]|90)\b""").find(q)?.value?.toIntOrNull()
        val targetDay = listOf("lundi","mardi","mercredi","jeudi","vendredi","samedi")
            .firstOrNull { it in q } ?: Analytics.nextTargetDay(draws)

        if (("jamais" in q || "absent" in q) && targetDay.isNotBlank()) {
            val dayDraws = draws.filter { it.day.equals(targetDay, true) }
            val seen = dayDraws.flatMap { it.numbers }.toSet()
            val never = (1..90).filter { it !in seen }
            return if (never.isEmpty()) "Tous les numéros 1–90 sont déjà sortis au moins une fois le ${targetDay.uppercase()}."
            else "Jamais sortis le ${targetDay.uppercase()} (${never.size}) :\n" + never.joinToString(" • ") { it.toString().padStart(2,'0') }
        }

        if ("top" in q && targetDay.isNotBlank() && "modèle" !in q && "score" !in q) {
            val dayDraws = draws.filter { it.day.equals(targetDay, true) }
            val freq = IntArray(91)
            dayDraws.forEach { d -> d.numbers.forEach { n -> if (n in 1..90) freq[n]++ } }
            val top = (1..90).map { it to freq[it] }.sortedWith(compareByDescending<Pair<Int,Int>> { it.second }.thenBy { it.first }).take(10)
            return top.joinToString(prefix = "TOP 10 ${targetDay.uppercase()} — ${dayDraws.size} tirages :\n", separator = "\n") { "• ${it.first.toString().padStart(2,'0')} — ${it.second} sortie(s)" }
        }

        if ("consensus" in q || "top score" in q || "top" in q && "modèle" in q) {
            val weights = AdvancedAnalytics.adaptiveWeights(draws)
            val top = AdvancedAnalytics.consensus(draws, targetDay, weights).take(10)
            return buildString {
                append("Consensus adaptatif pour ${targetDay.uppercase()}\n")
                top.forEachIndexed { i, s ->
                    append("${i+1}. ${s.number.toString().padStart(2,'0')} — ${"%.0f".format(s.consensus)}/100 — ${s.votes}/6 modèles\n")
                }
                append("\nPoids appris : ")
                append(weights.asList().joinToString(" • ") { "${it.first} ${"%.0f".format(it.second * 100)}%" })
            }
        }

        if ("chrono" in q || "jumeau" in q || "jumelle" in q || "similar" in q) {
            val twins = ChronoAnalytics.chronoMatches(draws, limit = 5)
            return if (twins.isEmpty()) "ChronoMatch indisponible : historique insuffisant." else buildString {
                append("ChronoMatch — 5 états historiques les plus proches :\n")
                twins.forEachIndexed { i, t ->
                    append("${i + 1}. ${t.date} ${t.day.uppercase()} — similarité ${"%.0f".format(t.similarity)}%")
                    t.nextDraw?.let { next -> append(" • suite historique ${next.numbers.joinToString("-")}") }
                    append("\n")
                }
                append("\nSimilarité descriptive, pas une certitude de tirage.")
            }
        }

        if ("simulation" in q || "arena" in q || "robust" in q) {
            val arena = ChronoAnalytics.simulationArena(draws, targetDay, size = 5, iterations = 240, seed = q.hashCode())
            return if (arena.entries.isEmpty()) "Simulation Arena indisponible." else buildString {
                append("Simulation Arena — ${arena.iterations} scénarios • ${targetDay.uppercase()}\n")
                append("Convergence des 5 leaders : ${"%.0f".format(arena.convergence)}%\n")
                arena.entries.take(10).forEachIndexed { i, e ->
                    append("${i + 1}. ${e.number.toString().padStart(2,'0')} — ${"%.0f".format(e.rate)}% • ${e.profileSupport}/${arena.profiles} profils\n")
                }
            }
        }

        if ("brief" in q || "univers" in q || "universe" in q) {
            val brief = UniverseAnalytics.brief(draws, targetDay)
            return brief.joinToString(prefix = "Universe Brief — ${targetDay.uppercase()} :\n", separator = "\n") { "• ${it.title} — ${it.detail}" }
        }

        if ("championnat" in q || "champion" in q || "league" in q || "ligue" in q) {
            val league = UniverseAnalytics.modelLeague(draws, targetDay, 60)
            return league.mapIndexed { i, e ->
                "${i + 1}. ${e.name} — indice ${"%.0f".format(e.universeScore)} • jour ${"%.2f".format(e.dayHits)} • global ${"%.2f".format(e.overallHits)}"
            }.joinToString(prefix = "Championnat des moteurs — ${targetDay.uppercase()} :\n", separator = "\n")
        }

        if (("dna" in q || "adn" in q) && number != null) {
            val d = UniverseAnalytics.dna(draws, number) ?: return "DNA indisponible pour $number."
            return buildString {
                append("DNA 90 — ${number.toString().padStart(2,'0')}\n")
                append("• Fréquence ${d.frequency} • 20 récents ${d.recent20} • retard ${d.currentDelay} • écart moyen ${"%.1f".format(d.averageGap)}\n")
                append("• Jours : ${d.dayCounts.joinToString(" • ") { "${it.first}:${it.second}" }}\n")
                append("• Positions : ${d.positionCounts.joinToString(" • ") { "${it.first}:${it.second}" }}\n")
                append("• Compagnons : ${d.companions.take(6).joinToString(" • ") { "${it.first}(${it.second})" }}")
            }
        }

        if (("galaxy" in q || "galaxie" in q || "affinités" in q || "affinites" in q) && number != null) {
            val g = UniverseAnalytics.galaxy(draws, number, 10)
            return if (g.isEmpty()) "Galaxy insuffisante pour $number."
            else g.joinToString(prefix = "Galaxy des affinités de $number :\n", separator = "\n") {
                "• ${it.number.toString().padStart(2,'0')} — force ${"%.0f".format(it.strength)} • compagnon ${it.companionCount}x • transition ${it.transitionCount}x"
            }
        }

        if ("smart" in q || "generator" in q || "générateur" in q || "generateur" in q) {
            val size = when {
                Regex("""\b2\b""").containsMatchIn(q) -> 2
                Regex("""\b3\b""").containsMatchIn(q) -> 3
                else -> 5
            }
            val profile = when {
                "prudent" in q -> "Prudent"
                "dynam" in q -> "Dynamique"
                "contrar" in q -> "Contrarian"
                "jour" in q -> "Jour"
                "affinit" in q -> "Affinités"
                "retard" in q -> "Retards"
                else -> "Consensus"
            }
            val pick = UniverseAnalytics.smartPick(draws, targetDay, size, profile, q.hashCode())
            return "Smart Generator $profile — ${targetDay.uppercase()} : ${pick.numbers.joinToString(" • ") { it.toString().padStart(2,'0') }}\nConfiance analytique ${"%.0f".format(pick.confidence)}/100. ${pick.rationale}"
        }

        if ("replay" in q) {
            val r = SignatureAnalytics.replay(draws, 1) ?: return "Pas assez de données pour Replay Lab."
            return buildString {
                append("Replay ${r.target.date} (${r.target.day.uppercase()})\n")
                append("• Réel : ${r.target.numbers.joinToString(" • ")}\n")
                append("• Consensus : ${r.consensusTop5.joinToString(" • ")} — ${r.consensusHits}/5\n")
                append("• Prudent : ${r.prudent.joinToString(" • ")} — ${r.prudentHits}/5\n")
                append("• Équilibré : ${r.balanced.joinToString(" • ")} — ${r.balancedHits}/5\n")
                append("• Explorateur : ${r.explorer.joinToString(" • ")} — ${r.explorerHits}/5")
            }
        }

        if ("battle" in q || "bataille" in q) {
            val battle = SignatureAnalytics.scenarioBattle(draws, 36)
            return battle.joinToString(prefix = "Scenario Battle — 36 replays :\n", separator = "\n") {
                "• ${it.mode} : ${"%.2f".format(it.averageHits)} hit/tirage • ${"%.0f".format(it.atLeast2Rate*100)}% avec ≥2 • best ${it.bestHits}/5"
            }
        }

        if ("position" in q || Regex("""\bn[1-5]\b""").containsMatchIn(q)) {
            val pos = Regex("""\bn([1-5])\b""").find(q)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 1
            val insight = SignatureAnalytics.positionInsights(draws).getOrNull(pos - 1) ?: return "Position introuvable."
            return buildString {
                append("Position N$pos\n")
                append("• TOP : ${insight.top.take(10).joinToString(" • ") { "${it.first}(${it.second})" }}\n")
                append("• Jamais sortis : ${if (insight.never.isEmpty()) "aucun" else insight.never.joinToString(" • ")}\n")
                append("• Leader récent : ${insight.recentLeader ?: "—"} (${insight.recentLeaderCount}x / 30)")
            }
        }

        if ("live" in q || "alerte" in q) {
            val alerts = SignatureAnalytics.liveAlerts(draws)
            return alerts.joinToString(prefix = "Live Intelligence :\n", separator = "\n") { "• ${it.title} — ${it.detail}" }
        }

        if ("backtest" in q || "performance" in q || "modèles" in q || "modeles" in q) {
            val perf = AdvancedAnalytics.modelBacktest(draws, 32)
            return buildString {
                append("Conseil des modèles — backtest récent\n")
                perf.forEach { p ->
                    append("• ${p.name} : ${"%.2f".format(p.averageHits)} hit/tirage, ${"%.0f".format(p.atLeast2Rate*100)}% avec ≥2, meilleur ${p.bestHits}/5\n")
                }
            }
        }

        if ("retard" in q) {
            return Analytics.delays(draws, 10).joinToString(
                prefix = "Top retards actuels :\n", separator = "\n"
            ) { "• ${it.number} — ${it.currentDelay} tirage(s), moyenne ${"%.1f".format(it.averageGap)}" }
        }

        if ("chaud" in q || "fréquence" in q || "frequence" in q) {
            return Analytics.hot(draws, 10).joinToString(
                prefix = "Activité sur les 20 derniers tirages :\n", separator = "\n"
            ) { "• ${it.number} — ${it.recent20} sortie(s)" }
        }

        if (("transition" in q || "après" in q || "apres" in q) && number != null) {
            val t = AdvancedAnalytics.transitions(draws, number, 8)
            return if (t.isEmpty()) "Pas assez de transitions historiques pour $number."
            else t.joinToString(prefix = "Numéros observés après un tirage contenant $number :\n", separator = "\n") {
                "• ${it.to} — ${it.count} fois"
            }
        }

        if (("compagnon" in q || "paire" in q) && number != null) {
            return Analytics.bestCompanions(draws, number, 8).joinToString(
                prefix = "Compagnons historiques de $number :\n", separator = "\n"
            ) { "• ${it.first} — ${it.second} association(s)" }
        }

        if ("profil" in q || "jour" in q) {
            val p = AdvancedAnalytics.dayProfile(draws, targetDay)
            return buildString {
                append("Profil ${targetDay.uppercase()} — ${p.drawCount} tirages\n")
                append("• Somme moyenne : ${"%.1f".format(p.averageSum)}\n")
                append("• Part impaire : ${"%.0f".format(p.oddRate*100)}%\n")
                append("• Numéros dominants : ${p.topNumbers.joinToString(" • ") { "${it.first}(${it.second})" }}")
            }
        }

        if ("régime" in q || "regime" in q || "température" in q || "temperature" in q) {
            val r = AdvancedAnalytics.regime(draws)
            return "Régime actuel : ${r.label} (${r.temperature}/100). Somme récente ${"%.1f".format(r.recentAverageSum)} vs historique ${"%.1f".format(r.longAverageSum)}, répétitions moyennes ${"%.2f".format(r.repeatRate)}."
        }

        if ("génère" in q || "genere" in q || "combinaison" in q || "scénario" in q || "scenario" in q) {
            val size = when {
                Regex("""\b2\b""").containsMatchIn(q) -> 2
                Regex("""\b3\b""").containsMatchIn(q) -> 3
                else -> 5
            }
            val mode = when {
                "prudent" in q -> "Prudent"
                "explor" in q -> "Explorateur"
                else -> "Équilibré"
            }
            val packs = AdvancedAnalytics.generateScenarios(draws, targetDay, size, mode, 3, q.hashCode())
            return packs.mapIndexed { index, s ->
                "${index+1}. ${s.numbers.joinToString(" • ") { it.toString().padStart(2,'0') }} — consensus ${"%.0f".format(s.score)} — stabilité ${"%.0f".format(s.stability)}%"
            }.joinToString(prefix = "3 scénarios $mode pour ${targetDay.uppercase()} :\n", separator = "\n")
        }

        if (number != null) {
            val signal = AdvancedAnalytics.consensus(draws, targetDay).firstOrNull { it.number == number }
                ?: return "Numéro introuvable."
            val companions = Analytics.bestCompanions(draws, number, 5)
            val transitions = AdvancedAnalytics.transitions(draws, number, 4)
            return buildString {
                append("Analyse augmentée du $number\n")
                append("• Consensus : ${"%.1f".format(signal.consensus)}/100 (${signal.votes}/6 modèles)\n")
                append("• Momentum : ${"%.0f".format(signal.momentum)} • Cycle : ${"%.0f".format(signal.cycle)} • Jour : ${"%.0f".format(signal.day)}\n")
                append("• Retard : ${signal.stat.currentDelay} • Écart moyen : ${"%.1f".format(signal.stat.averageGap)}\n")
                append("• Compagnons : ${companions.joinToString { "${it.first}(${it.second})" }}\n")
                append("• Après lui : ${transitions.joinToString { "${it.to}(${it.count})" }}")
            }
        }

        return "Je peux explorer l’historique complet, le TOP par jour, les numéros jamais sortis lundi–samedi, le consensus, les modèles, les transitions, les paires et les retards. Exemple : « jamais sortis samedi »."
    }
}
