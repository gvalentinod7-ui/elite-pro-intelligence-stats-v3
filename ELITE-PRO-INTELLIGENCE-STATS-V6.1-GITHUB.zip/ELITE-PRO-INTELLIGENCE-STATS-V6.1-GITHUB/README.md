# Élite-Pro Chrono Universe 6.1 ✨🌟🔥

Version expérimentale installable à côté de V5.4/V6.

## Nouveautés V6.1

### ChronoMatch
- Compare l'état actuel à tous les états historiques compatibles.
- Similarité basée sur empreinte du tirage, contexte roulant, numéros actifs et jour.
- Affiche ce qui s'est réellement produit au tirage suivant pour chaque jumeau historique.
- La similarité est descriptive et n'est jamais présentée comme une certitude.

### Pattern Fingerprint
- Somme, parité, zones, répétitions, étendue.
- Moyenne roulante, taux impair, répétitions et température de régime.

### Time Machine Slider
- Navigation fluide dans l'historique.
- La date suit le doigt immédiatement.
- Le moteur lourd se recalcule uniquement lorsque le curseur est relâché.
- Reconstruction du consensus, du régime et du brief avec uniquement les données connues à cette date.

### Simulation Arena
- 120 / 240 / 480 simulations.
- 7 philosophies : Consensus, Prudent, Dynamique, Contrarian, Jour, Affinités, Retards.
- Classe les numéros par robustesse multi-scénarios et soutien multi-profils.

## Studio fluide
Le Studio n'essaie plus de composer tous les laboratoires simultanément.
Il est découpé en quatre univers :
- LIVE
- CHRONO
- MODÈLES
- DNA

Les sous-laboratoires sont chargés uniquement lorsqu'ils sont ouverts.

## Matrice fluide 1–90
- Un seul flux vertical pour l'écran.
- 90 cellules à clés stables.
- Valeurs mises en cache par mode.
- Connexions calculées uniquement pour le numéro sélectionné.
- Focus rapide sur les leaders.
- Modes Consensus, Momentum, Retard et Jour.

## Socle conservé
- 180 tirages embarqués jusqu'au 10/08/2026.
- Calendrier et ajout depuis une date vide.
- Historique complet et lundi–samedi.
- Top et jamais sortis.
- Import/export JSON et CSV.
- Replay Lab Pro, Position Lab, Championnat des moteurs.
- DNA 90, Galaxy, Smart Generator, Live Intelligence, Elite AI.

## Android
- applicationId : `com.elitepro.intelligencestats.v61.dev` en build debug
- versionName : `6.1.0-dev`
- minSdk 23
- targetSdk 36
- Jetpack Compose
