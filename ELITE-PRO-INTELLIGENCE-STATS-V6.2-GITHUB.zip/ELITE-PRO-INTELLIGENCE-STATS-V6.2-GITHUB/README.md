# Élite-Pro Pulse Intelligence V6.2

Version expérimentale installable à côté de V6.1.

## Nouveautés V6.2

- **PULSE 1–90** : état dynamique de chaque numéro (Montée, Stable, Recul, Retour, Dormant, Surveillance), score Pulse et delta par rapport à l'état précédent.
- **Similarity Radar** : numéros dont le profil statistique actuel ressemble le plus au numéro sélectionné.
- **HeatFlow** : lecture des zones 1–30, 31–60 et 61–90 sur 5, 10, 20 et 50 tirages.
- **Story Mode** : cinq cartes qui racontent automatiquement ce qui a changé depuis le dernier tirage.
- **Decision Desk** : convergence des leaders, watchlists, montées et signaux contraires.
- **Timeline Intelligence** : évolution historique du leader, de la température du régime et de la zone dominante.
- **Studio modulaire et fluide** : PULSE / LIVE / CHRONO / MODÈLES / DNA, chaque module lourd n'est calculé que lorsqu'il est ouvert.
- **Matrice Fluide V6.1 conservée** sans régression.
- **Elite AI enrichi** : commandes `pulse`, `heatflow`, `story`, `decision desk`, `timeline`, `similaire 42`.

Le moteur est descriptif et statistique : les scores, scénarios et similarités ne constituent pas des certitudes de résultat.

## Build

Le workflow GitHub Actions `build-v6.2.yml` compile un APK debug Android API 36 avec Java 17 et Gradle 9.5.
