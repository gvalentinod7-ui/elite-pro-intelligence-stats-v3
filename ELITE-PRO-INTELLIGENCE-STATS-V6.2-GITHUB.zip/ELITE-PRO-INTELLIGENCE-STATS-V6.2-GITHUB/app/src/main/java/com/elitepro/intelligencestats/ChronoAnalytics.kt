package com.elitepro.intelligencestats

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * V6.1 Chrono Universe analytics.
 * Historical matching is descriptive: it compares past statistical states with
 * the current state and reports what happened next in those past cases.
 */
object ChronoAnalytics {
    data class PatternProfile(
        val date: String,
        val day: String,
        val fingerprint: DrawFingerprint,
        val rollingAverageSum: Double,
        val rollingOddRate: Double,
        val rollingRepeatRate: Double,
        val hotNumbers: Set<Int>,
        val regimeTemperature: Int
    )

    data class ChronoTwin(
        val index: Int,
        val date: String,
        val day: String,
        val similarity: Double,
        val fingerprintScore: Double,
        val contextScore: Double,
        val hotOverlap: Double,
        val dayAligned: Boolean,
        val fingerprint: DrawFingerprint,
        val nextDraw: Draw?
    )

    data class SimulationEntry(
        val number: Int,
        val appearances: Int,
        val rate: Double,
        val profileSupport: Int,
        val averageRankScore: Double
    )

    data class SimulationArena(
        val iterations: Int,
        val profiles: Int,
        val convergence: Double,
        val entries: List<SimulationEntry>
    )

    data class TimeSnapshot(
        val index: Int,
        val date: String,
        val day: String,
        val historySize: Int,
        val nextTargetDay: String,
        val regime: RegimeSnapshot,
        val leaders: List<ConsensusSignal>,
        val brief: List<UniverseAnalytics.UniverseBrief>
    )

    fun patternProfile(draws: List<Draw>, index: Int = draws.lastIndex, window: Int = 12): PatternProfile? {
        if (index !in draws.indices) return null
        val fp = AdvancedAnalytics.fingerprint(draws, index) ?: return null
        val start = max(0, index - window + 1)
        val slice = draws.subList(start, index + 1)
        val avgSum = slice.map { it.numbers.sum() }.average()
        val oddRate = slice.sumOf { d -> d.numbers.count { it % 2 != 0 } }.toDouble() / max(1.0, slice.size * 5.0)
        val repeats = slice.zipWithNext { a, b -> b.numbers.count { it in a.numbers } }
        val repeatRate = if (repeats.isEmpty()) 0.0 else repeats.average()
        val freq = IntArray(91)
        slice.takeLast(min(20, slice.size)).forEach { d -> d.numbers.forEach { n -> if (n in 1..90) freq[n]++ } }
        val hot = (1..90).sortedByDescending { freq[it] }.take(12).toSet()
        val regime = AdvancedAnalytics.regime(draws.subList(0, index + 1))
        return PatternProfile(draws[index].date, draws[index].day, fp, avgSum, oddRate, repeatRate, hot, regime.temperature)
    }

    fun chronoMatches(draws: List<Draw>, referenceIndex: Int = draws.lastIndex, limit: Int = 6): List<ChronoTwin> {
        val current = patternProfile(draws, referenceIndex) ?: return emptyList()
        if (referenceIndex < 20) return emptyList()
        val end = min(referenceIndex - 2, draws.lastIndex - 1)
        if (end < 12) return emptyList()

        return (12..end).mapNotNull { i ->
            val candidate = patternProfile(draws, i) ?: return@mapNotNull null
            val fpScore = fingerprintSimilarity(current.fingerprint, candidate.fingerprint)
            val sumScore = unitSimilarity(current.rollingAverageSum, candidate.rollingAverageSum, 180.0)
            val oddScore = unitSimilarity(current.rollingOddRate, candidate.rollingOddRate, 0.55)
            val repeatScore = unitSimilarity(current.rollingRepeatRate, candidate.rollingRepeatRate, 1.8)
            val regimeScore = unitSimilarity(current.regimeTemperature.toDouble(), candidate.regimeTemperature.toDouble(), 70.0)
            val contextScore = (sumScore * .34 + oddScore * .22 + repeatScore * .20 + regimeScore * .24) * 100.0
            val intersection = current.hotNumbers.intersect(candidate.hotNumbers).size.toDouble()
            val union = current.hotNumbers.union(candidate.hotNumbers).size.toDouble().coerceAtLeast(1.0)
            val hotOverlap = intersection / union * 100.0
            val sameDay = current.day.equals(candidate.day, true)
            val score = (
                fpScore * .46 +
                contextScore * .24 +
                hotOverlap * .20 +
                (if (sameDay) 100.0 else 38.0) * .10
            ).coerceIn(0.0, 100.0)
            ChronoTwin(
                index = i,
                date = candidate.date,
                day = candidate.day,
                similarity = score,
                fingerprintScore = fpScore,
                contextScore = contextScore,
                hotOverlap = hotOverlap,
                dayAligned = sameDay,
                fingerprint = candidate.fingerprint,
                nextDraw = draws.getOrNull(i + 1)
            )
        }.sortedByDescending { it.similarity }.take(limit)
    }

    fun simulationArena(
        draws: List<Draw>,
        targetDay: String,
        size: Int = 5,
        iterations: Int = 240,
        seed: Int = 61
    ): SimulationArena {
        val ranking = AdvancedAnalytics.consensus(draws, targetDay)
        if (ranking.isEmpty()) return SimulationArena(0, 0, 0.0, emptyList())
        val profiles = listOf("Consensus", "Prudent", "Dynamique", "Contrarian", "Jour", "Affinités", "Retards")
        val maxDelay = ranking.maxOf { it.stat.currentDelay }.coerceAtLeast(1)
        val counts = IntArray(91)
        val scoreSums = DoubleArray(91)
        val supports = Array(91) { mutableSetOf<String>() }
        val rng = Random(draws.size * 1_000_003 + targetDay.hashCode() * 97 + seed)
        val safeIterations = iterations.coerceIn(35, 800)

        repeat(safeIterations) { iteration ->
            val profile = profiles[iteration % profiles.size]
            val noisy = ranking.map { s ->
                val profileScore = when (profile) {
                    "Consensus" -> s.consensus + s.votes * 2.8
                    "Prudent" -> s.consensus * .74 + s.longTerm * .12 + s.day * .08 + s.votes * 2.2
                    "Dynamique" -> s.momentum * .54 + s.consensus * .33 + s.affinity * .09 + s.votes * 1.4
                    "Contrarian" -> (s.stat.currentDelay.toDouble() / maxDelay * 100.0) * .48 + (100.0 - s.momentum) * .24 + s.consensus * .20 + s.cycle * .08
                    "Jour" -> s.day * .58 + s.consensus * .30 + s.longTerm * .06 + s.votes * 1.5
                    "Affinités" -> s.affinity * .56 + s.consensus * .32 + s.momentum * .06 + s.votes * 1.5
                    else -> s.delay * .56 + s.consensus * .28 + s.cycle * .10 + s.votes * 1.2
                }
                val noise = when (profile) {
                    "Prudent" -> rng.nextDouble(-1.4, 1.4)
                    "Contrarian" -> rng.nextDouble(-5.2, 5.2)
                    else -> rng.nextDouble(-3.1, 3.1)
                }
                s to profileScore + noise
            }.sortedByDescending { it.second }

            val selected = mutableListOf<ConsensusSignal>()
            for ((candidate, _) in noisy) {
                val decade = (candidate.number - 1) / 10
                if (selected.count { (it.number - 1) / 10 == decade } >= 2) continue
                if (size >= 5 && selected.count { it.number % 2 == candidate.number % 2 } >= 4) continue
                selected += candidate
                if (selected.size == size) break
            }
            if (selected.size < size) {
                noisy.map { it.first }.filter { c -> selected.none { it.number == c.number } }
                    .take(size - selected.size).forEach { selected += it }
            }
            selected.forEachIndexed { rank, s ->
                counts[s.number]++
                scoreSums[s.number] += (size - rank).toDouble() / size * 100.0
                supports[s.number] += profile
            }
        }

        val entries = (1..90).filter { counts[it] > 0 }.map { n ->
            SimulationEntry(
                number = n,
                appearances = counts[n],
                rate = counts[n].toDouble() / safeIterations * 100.0,
                profileSupport = supports[n].size,
                averageRankScore = scoreSums[n] / counts[n]
            )
        }.sortedWith(compareByDescending<SimulationEntry> { it.rate }.thenByDescending { it.profileSupport }).take(18)

        val convergence = entries.take(size).map { it.rate }.averageOrZero()
        return SimulationArena(safeIterations, profiles.size, convergence, entries)
    }

    fun timeSnapshot(draws: List<Draw>, index: Int): TimeSnapshot? {
        if (draws.isEmpty()) return null
        val safeIndex = index.coerceIn(0, draws.lastIndex)
        val history = draws.subList(0, safeIndex + 1)
        if (history.size < 12) return null
        val targetDay = Analytics.nextTargetDay(history)
        val weights = AdvancedAnalytics.adaptiveWeights(history, samples = min(24, max(6, history.size - 12)))
        val leaders = AdvancedAnalytics.consensus(history, targetDay, weights).take(8)
        return TimeSnapshot(
            index = safeIndex,
            date = draws[safeIndex].date,
            day = draws[safeIndex].day,
            historySize = history.size,
            nextTargetDay = targetDay,
            regime = AdvancedAnalytics.regime(history),
            leaders = leaders,
            brief = UniverseAnalytics.brief(history, targetDay).take(4)
        )
    }

    private fun fingerprintSimilarity(a: DrawFingerprint, b: DrawFingerprint): Double {
        val sum = unitSimilarity(a.sum.toDouble(), b.sum.toDouble(), 330.0)
        val parity = unitSimilarity(a.odd.toDouble(), b.odd.toDouble(), 5.0)
        val zone = unitSimilarity(a.low.toDouble(), b.low.toDouble(), 5.0)
        val repeat = unitSimilarity(a.repeatsFromPrevious.toDouble(), b.repeatsFromPrevious.toDouble(), 5.0)
        val spread = unitSimilarity(a.spread.toDouble(), b.spread.toDouble(), 89.0)
        return ((sum * .34 + parity * .16 + zone * .14 + repeat * .14 + spread * .22) * 100.0).coerceIn(0.0, 100.0)
    }

    private fun unitSimilarity(a: Double, b: Double, scale: Double): Double =
        (1.0 - abs(a - b) / max(0.0001, scale)).coerceIn(0.0, 1.0)

    private fun List<Double>.averageOrZero(): Double = if (isEmpty()) 0.0 else average()
}
