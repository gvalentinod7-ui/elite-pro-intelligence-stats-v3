package com.elitepro.intelligencestats

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * V6.2 Pulse Intelligence.
 * All signals are descriptive/statistical and are derived only from available history.
 */
object PulseAnalytics {
    data class PulseSignal(
        val number: Int,
        val state: String,
        val pulse: Double,
        val delta: Double,
        val recent5: Int,
        val recent20: Int,
        val delay: Int,
        val dayAffinity: Double,
        val votes: Int
    )

    data class HeatFlow(
        val window: Int,
        val low: Double,
        val mid: Double,
        val high: Double,
        val dominant: String
    )

    data class StoryCard(val title: String, val detail: String, val level: Int)

    data class DecisionDesk(
        val leaders: List<PulseSignal>,
        val convergence: Int,
        val rising: List<Int>,
        val watch: List<Int>,
        val counterSignals: List<Int>,
        val summary: String
    )

    data class TimelinePoint(
        val index: Int,
        val date: String,
        val day: String,
        val leader: Int,
        val temperature: Int,
        val dominantZone: String,
        val score: Double
    )

    data class SimilarState(
        val number: Int,
        val similarity: Double,
        val currentState: String,
        val comparedState: String
    )

    fun pulse(draws: List<Draw>, targetDay: String): List<PulseSignal> {
        if (draws.isEmpty()) return emptyList()
        val now = AdvancedAnalytics.consensus(draws, targetDay)
        val previous = if (draws.size > 8) AdvancedAnalytics.consensus(draws.dropLast(1), targetDay).associateBy { it.number } else emptyMap()
        val recent5Counts = counts(draws.takeLast(min(5, draws.size)))
        return now.map { s ->
            val prev = previous[s.number]?.consensus ?: s.consensus
            val delta = s.consensus - prev
            val recent5 = recent5Counts[s.number]
            val state = when {
                s.consensus >= 72 && delta >= 2.2 -> "MONTÉE"
                s.stat.currentDelay >= 18 && s.delay >= 58 -> "SURVEILLANCE"
                delta <= -5.0 -> "RECUL"
                recent5 == 0 && s.stat.currentDelay >= 12 -> "DORMANT"
                abs(delta) <= 2.0 -> "STABLE"
                delta > 2.0 -> "MONTÉE"
                else -> "RETOUR"
            }
            val pulse = (s.consensus * .58 + s.momentum * .18 + s.day * .10 + s.votes * 2.3 + (delta + 12.0).coerceIn(0.0, 24.0) * .35)
                .coerceIn(0.0, 100.0)
            PulseSignal(s.number, state, pulse, delta, recent5, s.stat.recent20, s.stat.currentDelay, s.day, s.votes)
        }.sortedWith(compareByDescending<PulseSignal> { it.pulse }.thenByDescending { it.votes })
    }

    fun heatFlow(draws: List<Draw>, windows: List<Int> = listOf(5, 10, 20, 50)): List<HeatFlow> = windows.map { w ->
        val slice = draws.takeLast(min(w, draws.size))
        val total = max(1, slice.size * 5).toDouble()
        var low = 0; var mid = 0; var high = 0
        slice.forEach { d -> d.numbers.forEach { n ->
            when (n) { in 1..30 -> low++; in 31..60 -> mid++; in 61..90 -> high++ }
        } }
        val l = low / total * 100.0; val m = mid / total * 100.0; val h = high / total * 100.0
        val dom = when (maxOf(l, m, h)) { l -> "1–30"; m -> "31–60"; else -> "61–90" }
        HeatFlow(w, l, m, h, dom)
    }

    fun story(draws: List<Draw>, targetDay: String): List<StoryCard> {
        if (draws.size < 3) return emptyList()
        val current = pulse(draws, targetDay)
        val previous = pulse(draws.dropLast(1), targetDay)
        val nowLeader = current.firstOrNull()
        val oldLeader = previous.firstOrNull()
        val pairsNow = AdvancedAnalytics.topPairs(draws, 24, 5)
        val pairsOld = AdvancedAnalytics.topPairs(draws.dropLast(1), 24, 5)
        val delays = Analytics.delays(draws, 4)
        val flow = heatFlow(draws, listOf(10)).firstOrNull()
        val last = draws.last()
        val fp = AdvancedAnalytics.fingerprint(draws)
        val cards = mutableListOf<StoryCard>()

        if (nowLeader != null) {
            cards += if (oldLeader != null && oldLeader.number != nowLeader.number)
                StoryCard("Nouveau leader ${fmt(nowLeader.number)}", "${fmt(oldLeader.number)} cède la tête. ${fmt(nowLeader.number)} passe à ${"%.0f".format(nowLeader.pulse)}/100 de Pulse.", 3)
            else StoryCard("Leader confirmé ${fmt(nowLeader.number)}", "${nowLeader.votes}/6 moteurs le soutiennent • état ${nowLeader.state.lowercase()}.", 2)
        }
        val risingPair = pairsNow.firstOrNull { p -> pairsOld.none { it.first == p.first && it.second == p.second } }
        val p = risingPair ?: pairsNow.firstOrNull()
        if (p != null) cards += StoryCard("Affinité ${fmt(p.first)}–${fmt(p.second)}", "${p.recent} présence(s) dans la fenêtre récente • ${p.total} au total.", if (risingPair != null) 3 else 2)
        delays.firstOrNull()?.let { d -> cards += StoryCard("Retard sous surveillance ${fmt(d.number)}", "${d.currentDelay} tirages depuis sa dernière apparition.", 2) }
        flow?.let { f -> cards += StoryCard("HeatFlow ${f.dominant}", "Sur 10 tirages : 1–30 ${"%.0f".format(f.low)}% • 31–60 ${"%.0f".format(f.mid)}% • 61–90 ${"%.0f".format(f.high)}%.", 1) }
        if (fp != null) cards += StoryCard("Empreinte du ${last.date}", "Σ${fp.sum} • ${fp.even} pairs/${fp.odd} impairs • étendue ${fp.spread} • ${fp.repeatsFromPrevious} répétition(s).", 1)
        return cards.take(5)
    }

    fun decisionDesk(draws: List<Draw>, targetDay: String): DecisionDesk {
        val p = pulse(draws, targetDay)
        val leaders = p.take(6)
        val convergence = leaders.count { it.votes >= 4 }
        val rising = p.filter { it.state == "MONTÉE" }.take(8).map { it.number }
        val watch = p.filter { it.state == "SURVEILLANCE" || it.state == "DORMANT" }.take(8).map { it.number }
        val counter = p.filter { it.pulse >= 48 && it.votes <= 2 && (it.state == "RETOUR" || it.state == "SURVEILLANCE") }.take(8).map { it.number }
        val summary = when {
            convergence >= 4 -> "Convergence élevée : plusieurs moteurs racontent la même histoire."
            convergence >= 2 -> "Convergence modérée : quelques leaders se détachent, mais le paysage reste ouvert."
            else -> "Convergence faible : les moteurs divergent, le contexte est plus exploratoire."
        }
        return DecisionDesk(leaders, convergence, rising, watch, counter, summary)
    }

    fun timeline(draws: List<Draw>, points: Int = 16): List<TimelinePoint> {
        if (draws.size < 15) return emptyList()
        val start = max(12, draws.size - max(points * 5, 60))
        val step = max(1, (draws.lastIndex - start) / max(1, points - 1))
        val indices = generateSequence(start) { it + step }.takeWhile { it < draws.lastIndex }.toMutableList().apply { if (lastOrNull() != draws.lastIndex) add(draws.lastIndex) }
        return indices.distinct().mapNotNull { idx ->
            val history = draws.subList(0, idx + 1)
            val target = Analytics.nextTargetDay(history)
            val top = AdvancedAnalytics.consensus(history, target).firstOrNull() ?: return@mapNotNull null
            val regime = AdvancedAnalytics.regime(history)
            val f = heatFlow(history, listOf(10)).first()
            TimelinePoint(idx, draws[idx].date, draws[idx].day, top.number, regime.temperature, f.dominant, top.consensus)
        }.takeLast(points)
    }

    fun similarNumbers(draws: List<Draw>, number: Int, targetDay: String, limit: Int = 8): List<SimilarState> {
        val p = pulse(draws, targetDay).associateBy { it.number }
        val ref = p[number] ?: return emptyList()
        return p.values.filter { it.number != number }.map { other ->
            val pulseSim = 1.0 - abs(ref.pulse - other.pulse) / 100.0
            val delayScale = max(8.0, max(ref.delay, other.delay).toDouble())
            val delaySim = 1.0 - abs(ref.delay - other.delay) / delayScale
            val recentSim = 1.0 - abs(ref.recent20 - other.recent20) / max(1.0, max(ref.recent20, other.recent20).toDouble())
            val daySim = 1.0 - abs(ref.dayAffinity - other.dayAffinity) / 100.0
            val score = (pulseSim * .40 + delaySim * .23 + recentSim * .20 + daySim * .17) * 100.0
            SimilarState(other.number, score.coerceIn(0.0, 100.0), ref.state, other.state)
        }.sortedByDescending { it.similarity }.take(limit)
    }

    private fun counts(draws: List<Draw>): IntArray = IntArray(91).also { a -> draws.forEach { d -> d.numbers.forEach { if (it in 1..90) a[it]++ } } }
    private fun fmt(n: Int) = n.toString().padStart(2, '0')
}
