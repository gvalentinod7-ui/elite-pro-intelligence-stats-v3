package com.elitepro.intelligencestats

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

object AdvancedAnalytics {
    private val modelNames = listOf("Momentum", "Cycle", "Affinités", "Jour", "Retard", "Historique")

    fun adaptiveWeights(draws: List<Draw>, samples: Int = 36): AdaptiveWeights {
        if (draws.size < 30) return AdaptiveWeights(.22, .16, .17, .14, .17, .14)
        val start = max(24, draws.size - samples)
        val hits = DoubleArray(6) { 1.0 }
        var tested = 0

        for (i in start until draws.size) {
            val history = draws.subList(0, i)
            val target = draws[i]
            val stats = Analytics.stats(history, target.day)
            if (stats.isEmpty()) continue
            val maxFreq = stats.maxOf { it.frequency }.coerceAtLeast(1)
            val signals = stats.map { s -> rawSignals(s, maxFreq) }
            val actual = target.numbers.toSet()
            for (m in 0..5) {
                val top = signals.sortedByDescending { it[m] }.take(5)
                hits[m] = hits[m] + top.count { it[6].toInt() in actual }.toDouble()
            }
            tested++
        }

        if (tested == 0) return AdaptiveWeights(.22, .16, .17, .14, .17, .14)
        val softened = hits.map { max(2.0, it) }
        val total = softened.sum()
        val w = softened.map { it / total }
        return AdaptiveWeights(w[0], w[1], w[2], w[3], w[4], w[5])
    }

    fun consensus(draws: List<Draw>, targetDay: String, weights: AdaptiveWeights = adaptiveWeights(draws)): List<ConsensusSignal> {
        val stats = Analytics.stats(draws, targetDay)
        if (stats.isEmpty()) return emptyList()
        val maxFreq = stats.maxOf { it.frequency }.coerceAtLeast(1)

        val components = stats.associate { s ->
            val raw = rawSignals(s, maxFreq)
            s.number to raw
        }

        val topSets = (0..5).map { index ->
            components.entries.sortedByDescending { it.value[index] }.take(12).map { it.key }.toSet()
        }

        return stats.map { s ->
            val r = components.getValue(s.number)
            val score = (
                r[0] * weights.momentum +
                r[1] * weights.cycle +
                r[2] * weights.affinity +
                r[3] * weights.day +
                r[4] * weights.delay +
                r[5] * weights.longTerm
            ).coerceIn(0.0, 100.0)
            ConsensusSignal(
                number = s.number,
                momentum = r[0], cycle = r[1], affinity = r[2], day = r[3],
                delay = r[4], longTerm = r[5], consensus = score,
                votes = topSets.count { s.number in it }, stat = s
            )
        }.sortedWith(compareByDescending<ConsensusSignal> { it.votes }.thenByDescending { it.consensus })
    }

    fun generateScenarios(
        draws: List<Draw>,
        targetDay: String,
        size: Int,
        mode: String,
        count: Int = 3,
        seed: Int = 1
    ): List<ScenarioPack> {
        val weights = adaptiveWeights(draws)
        val ranking = consensus(draws, targetDay, weights)
        if (ranking.isEmpty()) return emptyList()
        val rng = Random(draws.size * 7919 + seed * 104729 + mode.hashCode())
        val poolSize = when (mode) {
            "Prudent" -> 18
            "Explorateur" -> 36
            else -> 26
        }
        val pool = ranking.take(poolSize)
        val output = mutableListOf<ScenarioPack>()

        repeat(count) { scenarioIndex ->
            val scored = pool.map { s ->
                val jitter = when (mode) {
                    "Prudent" -> rng.nextDouble(-1.5, 1.5)
                    "Explorateur" -> rng.nextDouble(-9.0, 9.0)
                    else -> rng.nextDouble(-4.0, 4.0)
                }
                s to (s.consensus + s.votes * 2.2 + jitter - scenarioIndex * .15)
            }.sortedByDescending { it.second }

            val picked = mutableListOf<ConsensusSignal>()
            for ((candidate, _) in scored) {
                val decade = (candidate.number - 1) / 10
                if (picked.count { (it.number - 1) / 10 == decade } >= 2) continue
                if (size >= 5 && picked.count { it.number % 2 == candidate.number % 2 } >= 4) continue
                if (output.any { previous -> previous.numbers.contains(candidate.number) } && mode == "Explorateur" && picked.size < size - 1) {
                    if (rng.nextDouble() < .38) continue
                }
                picked += candidate
                if (picked.size == size) break
            }
            if (picked.size < size) {
                ranking.filter { r -> picked.none { it.number == r.number } }
                    .take(size - picked.size).forEach { picked += it }
            }
            val nums = picked.map { it.number }.sorted()
            val avg = picked.map { it.consensus }.average()
            val voteStability = picked.map { it.votes / 6.0 }.average() * 100.0
            val decades = nums.map { (it - 1) / 10 }.distinct().size
            val parityBalance = 1.0 - abs(nums.count { it % 2 == 0 } - nums.count { it % 2 != 0 }).toDouble() / max(1, size)
            val diversity = ((decades.toDouble() / size) * .6 + parityBalance * .4) * 100.0
            output += ScenarioPack(nums, avg, voteStability, diversity, when (mode) {
                "Prudent" -> "Consensus fort"
                "Explorateur" -> "Diversification"
                else -> "Équilibre adaptatif"
            })
        }
        return output
    }

    fun topPairs(draws: List<Draw>, window: Int = 60, count: Int = 12): List<PairInsight> {
        val all = HashMap<Int, Int>()
        val recent = HashMap<Int, Int>()
        val recentStart = max(0, draws.size - window)
        draws.forEachIndexed { index, d ->
            val nums = d.numbers.distinct().sorted()
            for (i in nums.indices) for (j in i + 1 until nums.size) {
                val key = nums[i] * 100 + nums[j]
                all[key] = (all[key] ?: 0) + 1
                if (index >= recentStart) recent[key] = (recent[key] ?: 0) + 1
            }
        }
        return all.entries.map { (key, total) ->
            PairInsight(key / 100, key % 100, total, recent[key] ?: 0)
        }.sortedWith(compareByDescending<PairInsight> { it.recent }.thenByDescending { it.total }).take(count)
    }

    fun transitions(draws: List<Draw>, from: Int, count: Int = 8): List<TransitionInsight> {
        val counts = IntArray(91)
        for (i in 0 until draws.lastIndex) {
            if (from in draws[i].numbers) {
                draws[i + 1].numbers.forEach { n -> if (n in 1..90) counts[n]++ }
            }
        }
        return (1..90).filter { it != from && counts[it] > 0 }
            .map { TransitionInsight(from, it, counts[it]) }
            .sortedByDescending { it.count }.take(count)
    }

    fun fingerprint(draws: List<Draw>, index: Int = draws.lastIndex): DrawFingerprint? {
        if (index !in draws.indices) return null
        val nums = draws[index].numbers
        val prev = draws.getOrNull(index - 1)?.numbers?.toSet().orEmpty()
        return DrawFingerprint(
            sum = nums.sum(), odd = nums.count { it % 2 != 0 }, even = nums.count { it % 2 == 0 },
            low = nums.count { it <= 45 }, high = nums.count { it > 45 },
            repeatsFromPrevious = nums.count { it in prev },
            spread = (nums.maxOrNull() ?: 0) - (nums.minOrNull() ?: 0)
        )
    }

    fun regime(draws: List<Draw>): RegimeSnapshot {
        if (draws.isEmpty()) return RegimeSnapshot("Neutre", 50, 0.0, 0.0, 0.0, 0.0)
        val recent = draws.takeLast(min(20, draws.size))
        val recentAvg = recent.map { it.numbers.sum() }.average()
        val longAvg = draws.map { it.numbers.sum() }.average()
        val repeatPairs = recent.zipWithNext { a, b -> b.numbers.count { it in a.numbers } }
        val repeatRate = if (repeatPairs.isEmpty()) 0.0 else repeatPairs.average()
        val oddRate = recent.sumOf { d -> d.numbers.count { it % 2 != 0 } }.toDouble() / (recent.size * 5.0)
        val delta = if (longAvg == 0.0) 0.0 else (recentAvg - longAvg) / longAvg
        val temp = (50 + delta * 160 + (repeatRate - .25) * 28 + (oddRate - .5) * 20).toInt().coerceIn(15, 92)
        val label = when {
            temp >= 72 -> "Accéléré"
            temp >= 58 -> "Actif"
            temp <= 34 -> "Calme"
            else -> "Équilibré"
        }
        return RegimeSnapshot(label, temp, recentAvg, longAvg, repeatRate, oddRate)
    }

    fun dayProfile(draws: List<Draw>, day: String): DayProfile {
        val filtered = draws.filter { it.day.equals(day, true) }
        if (filtered.isEmpty()) return DayProfile(day, 0, 0.0, 0.0, emptyList())
        val freq = IntArray(91)
        filtered.forEach { d -> d.numbers.forEach { n -> if (n in 1..90) freq[n]++ } }
        val top = (1..90).map { it to freq[it] }.sortedByDescending { it.second }.take(8)
        val avgSum = filtered.map { it.numbers.sum() }.average()
        val oddRate = filtered.sumOf { d -> d.numbers.count { it % 2 != 0 } }.toDouble() / (filtered.size * 5.0)
        return DayProfile(day, filtered.size, avgSum, oddRate, top)
    }

    fun modelBacktest(draws: List<Draw>, samples: Int = 32): List<ModelPerformance> {
        if (draws.size < 30) return emptyList()
        val start = max(24, draws.size - samples)
        val totalHits = IntArray(6)
        val atLeast2 = IntArray(6)
        val best = IntArray(6)
        var tested = 0
        for (i in start until draws.size) {
            val history = draws.subList(0, i)
            val target = draws[i]
            val stats = Analytics.stats(history, target.day)
            if (stats.isEmpty()) continue
            val maxFreq = stats.maxOf { it.frequency }.coerceAtLeast(1)
            val rows = stats.map { rawSignals(it, maxFreq) }
            val actual = target.numbers.toSet()
            for (m in 0..5) {
                val h = rows.sortedByDescending { it[m] }.take(5).count { it[6].toInt() in actual }
                totalHits[m] += h
                if (h >= 2) atLeast2[m]++
                best[m] = max(best[m], h)
            }
            tested++
        }
        if (tested == 0) return emptyList()
        return modelNames.indices.map { m ->
            ModelPerformance(modelNames[m], totalHits[m].toDouble() / tested, atLeast2[m].toDouble() / tested, best[m])
        }.sortedByDescending { it.averageHits }
    }

    private fun rawSignals(s: NumberStat, maxFreq: Int): DoubleArray {
        val momentum = (s.momentum * 100.0).coerceIn(0.0, 100.0)
        val cycle = (s.cycleScore * 100.0).coerceIn(0.0, 100.0)
        val affinity = (s.pairAffinity * 100.0).coerceIn(0.0, 100.0)
        val day = (s.dayAffinity * 100.0).coerceIn(0.0, 100.0)
        val ratio = s.currentDelay / max(1.0, s.averageGap)
        val delay = min(100.0, ratio / 1.8 * 100.0)
        val longTerm = s.frequency.toDouble() / maxFreq * 100.0
        return doubleArrayOf(momentum, cycle, affinity, day, delay, longTerm, s.number.toDouble())
    }
}
