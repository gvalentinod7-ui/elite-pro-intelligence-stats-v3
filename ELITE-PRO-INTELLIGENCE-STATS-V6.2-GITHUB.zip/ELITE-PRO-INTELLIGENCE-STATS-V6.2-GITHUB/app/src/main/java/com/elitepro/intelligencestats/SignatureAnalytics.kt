package com.elitepro.intelligencestats

import kotlin.math.max

/**
 * V5.4 Signature analytics.
 * All replay/backtest helpers build their state only from draws that existed
 * before the target draw, so the historical comparison does not peek ahead.
 */
object SignatureAnalytics {
    data class ReplaySnapshot(
        val target: Draw,
        val historySize: Int,
        val consensusTop5: List<Int>,
        val consensusHits: Int,
        val prudent: List<Int>,
        val prudentHits: Int,
        val balanced: List<Int>,
        val balancedHits: Int,
        val explorer: List<Int>,
        val explorerHits: Int
    )

    data class PositionInsight(
        val position: Int,
        val top: List<Pair<Int, Int>>,
        val never: List<Int>,
        val recentLeader: Int?,
        val recentLeaderCount: Int
    )

    data class BattlePerformance(
        val mode: String,
        val tested: Int,
        val averageHits: Double,
        val atLeast2Rate: Double,
        val bestHits: Int
    )

    data class LiveAlert(val title: String, val detail: String, val level: Int)

    fun replay(draws: List<Draw>, offsetFromEnd: Int = 1): ReplaySnapshot? {
        if (draws.size < 25) return null
        val targetIndex = (draws.lastIndex - (offsetFromEnd - 1)).coerceIn(20, draws.lastIndex)
        val target = draws[targetIndex]
        val history = draws.subList(0, targetIndex)
        if (history.size < 20) return null
        val actual = target.numbers.toSet()
        val consensusTop = AdvancedAnalytics.consensus(history, target.day).take(5).map { it.number }
        val prudent = AdvancedAnalytics.generateScenarios(history, target.day, 5, "Prudent", 1, targetIndex).firstOrNull()?.numbers.orEmpty()
        val balanced = AdvancedAnalytics.generateScenarios(history, target.day, 5, "Équilibré", 1, targetIndex).firstOrNull()?.numbers.orEmpty()
        val explorer = AdvancedAnalytics.generateScenarios(history, target.day, 5, "Explorateur", 1, targetIndex).firstOrNull()?.numbers.orEmpty()
        fun hits(nums: List<Int>) = nums.count { it in actual }
        return ReplaySnapshot(
            target, history.size,
            consensusTop, hits(consensusTop),
            prudent, hits(prudent),
            balanced, hits(balanced),
            explorer, hits(explorer)
        )
    }

    fun positionInsights(draws: List<Draw>): List<PositionInsight> {
        return (0..4).map { pos ->
            val counts = IntArray(91)
            draws.forEach { d -> d.numbers.getOrNull(pos)?.let { n -> if (n in 1..90) counts[n]++ } }
            val top = (1..90).map { it to counts[it] }
                .sortedWith(compareByDescending<Pair<Int, Int>> { it.second }.thenBy { it.first })
                .take(10)
            val never = (1..90).filter { counts[it] == 0 }
            val recentCounts = IntArray(91)
            draws.takeLast(30).forEach { d -> d.numbers.getOrNull(pos)?.let { n -> if (n in 1..90) recentCounts[n]++ } }
            val recentLeader = (1..90).maxByOrNull { recentCounts[it] }?.takeIf { recentCounts[it] > 0 }
            PositionInsight(pos + 1, top, never, recentLeader, recentLeader?.let { recentCounts[it] } ?: 0)
        }
    }

    fun scenarioBattle(draws: List<Draw>, samples: Int = 36): List<BattlePerformance> {
        if (draws.size < 35) return emptyList()
        val modes = listOf("Prudent", "Équilibré", "Explorateur")
        val start = max(25, draws.size - samples)
        return modes.map { mode ->
            var tested = 0
            var totalHits = 0
            var atLeast2 = 0
            var best = 0
            for (i in start until draws.size) {
                val history = draws.subList(0, i)
                val target = draws[i]
                val picks = AdvancedAnalytics.generateScenarios(history, target.day, 5, mode, 1, i).firstOrNull()?.numbers.orEmpty()
                if (picks.size != 5) continue
                val hits = target.numbers.count { it in picks }
                tested++
                totalHits += hits
                if (hits >= 2) atLeast2++
                best = max(best, hits)
            }
            BattlePerformance(
                mode = mode,
                tested = tested,
                averageHits = if (tested == 0) 0.0 else totalHits.toDouble() / tested,
                atLeast2Rate = if (tested == 0) 0.0 else atLeast2.toDouble() / tested,
                bestHits = best
            )
        }.sortedByDescending { it.averageHits }
    }

    fun liveAlerts(draws: List<Draw>): List<LiveAlert> {
        if (draws.isEmpty()) return emptyList()
        val targetDay = Analytics.nextTargetDay(draws)
        val consensus = AdvancedAnalytics.consensus(draws, targetDay)
        val delays = Analytics.delays(draws, 10)
        val pairs = AdvancedAnalytics.topPairs(draws, 60, 8)
        val regime = AdvancedAnalytics.regime(draws)
        val alerts = mutableListOf<LiveAlert>()

        consensus.firstOrNull()?.let { top ->
            if (top.votes >= 5) alerts += LiveAlert("Consensus élevé", "${top.number.toString().padStart(2, '0')} est soutenu par ${top.votes}/6 modèles.", 3)
            else if (top.votes >= 4) alerts += LiveAlert("Convergence", "${top.number.toString().padStart(2, '0')} reçoit ${top.votes}/6 votes modèles.", 2)
        }
        delays.firstOrNull()?.let { d ->
            val ratio = d.currentDelay / max(1.0, d.averageGap)
            if (ratio >= 1.7) alerts += LiveAlert("Retard atypique", "${d.number.toString().padStart(2, '0')} : ${d.currentDelay} tirages, moyenne ${"%.1f".format(d.averageGap)}.", 2)
        }
        pairs.firstOrNull()?.let { p ->
            if (p.recent >= 2) alerts += LiveAlert("Paire active", "${p.first.toString().padStart(2,'0')} + ${p.second.toString().padStart(2,'0')} : ${p.recent} occurrences récentes.", 1)
        }
        alerts += LiveAlert("Régime ${regime.label}", "Température analytique ${regime.temperature}/100 • cible ${targetDay.uppercase()}.", 1)
        return alerts.take(4)
    }
}
