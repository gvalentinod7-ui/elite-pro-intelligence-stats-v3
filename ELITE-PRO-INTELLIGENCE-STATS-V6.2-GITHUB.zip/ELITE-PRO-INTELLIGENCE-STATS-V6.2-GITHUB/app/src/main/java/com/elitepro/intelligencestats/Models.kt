package com.elitepro.intelligencestats

data class Draw(
    val date: String,
    val day: String,
    val numbers: List<Int>,
    val source: String = "base"
)

data class NumberStat(
    val number: Int,
    val frequency: Int,
    val recent20: Int,
    val recent50: Int,
    val currentDelay: Int,
    val averageGap: Double,
    val dayAffinity: Double,
    val pairAffinity: Double,
    val momentum: Double,
    val cycleScore: Double,
    val score: Double
)

data class BacktestResult(
    val tested: Int,
    val totalHits: Int,
    val averageHits: Double,
    val hitAtLeast2: Int,
    val hitAtLeast3: Int,
    val bestHits: Int
)

data class AdaptiveWeights(
    val momentum: Double,
    val cycle: Double,
    val affinity: Double,
    val day: Double,
    val delay: Double,
    val longTerm: Double
) {
    fun asList(): List<Pair<String, Double>> = listOf(
        "Momentum" to momentum,
        "Cycle" to cycle,
        "Affinités" to affinity,
        "Jour" to day,
        "Retard" to delay,
        "Historique" to longTerm
    )
}

data class ConsensusSignal(
    val number: Int,
    val momentum: Double,
    val cycle: Double,
    val affinity: Double,
    val day: Double,
    val delay: Double,
    val longTerm: Double,
    val consensus: Double,
    val votes: Int,
    val stat: NumberStat
)

data class ScenarioPack(
    val numbers: List<Int>,
    val score: Double,
    val stability: Double,
    val diversity: Double,
    val label: String
)

data class PairInsight(
    val first: Int,
    val second: Int,
    val total: Int,
    val recent: Int
)

data class TransitionInsight(
    val from: Int,
    val to: Int,
    val count: Int
)

data class DrawFingerprint(
    val sum: Int,
    val odd: Int,
    val even: Int,
    val low: Int,
    val high: Int,
    val repeatsFromPrevious: Int,
    val spread: Int
)

data class RegimeSnapshot(
    val label: String,
    val temperature: Int,
    val recentAverageSum: Double,
    val longAverageSum: Double,
    val repeatRate: Double,
    val oddRate: Double
)

data class ModelPerformance(
    val name: String,
    val averageHits: Double,
    val atLeast2Rate: Double,
    val bestHits: Int
)

data class DayProfile(
    val day: String,
    val drawCount: Int,
    val averageSum: Double,
    val oddRate: Double,
    val topNumbers: List<Pair<Int, Int>>
)
