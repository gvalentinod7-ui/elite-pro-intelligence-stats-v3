package com.elitepro.intelligencestats

import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * Intelligence Universe 6.0.
 * The functions in this object are deterministic and historical/replay computations
 * never inspect a draw that occurs after the target being evaluated.
 */
object UniverseAnalytics {
    private val models = listOf("Momentum", "Cycle", "Affinités", "Jour", "Retard", "Historique")
    private val days = listOf("lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi")

    data class ModelLeagueEntry(
        val name: String,
        val overallHits: Double,
        val dayHits: Double,
        val atLeast2Rate: Double,
        val bestHits: Int,
        val universeScore: Double
    )

    data class ReplayPoint(val date: String, val day: String, val hits: Int)

    data class NumberDNA(
        val number: Int,
        val frequency: Int,
        val recent20: Int,
        val currentDelay: Int,
        val averageGap: Double,
        val dayCounts: List<Pair<String, Int>>,
        val positionCounts: List<Pair<String, Int>>,
        val companions: List<Pair<Int, Int>>,
        val transitions: List<TransitionInsight>,
        val pulse: List<Pair<String, Double>>
    )

    data class GalaxyNode(
        val number: Int,
        val companionCount: Int,
        val transitionCount: Int,
        val strength: Double
    )

    data class SmartPick(
        val profile: String,
        val numbers: List<Int>,
        val confidence: Double,
        val rationale: String
    )

    data class UniverseBrief(val title: String, val detail: String, val level: Int)

    fun modelLeague(draws: List<Draw>, targetDay: String, samples: Int = 60): List<ModelLeagueEntry> {
        if (draws.size < 30) return emptyList()
        val start = max(24, draws.size - samples)
        val totalHits = IntArray(6)
        val dayHits = IntArray(6)
        val atLeast2 = IntArray(6)
        val best = IntArray(6)
        var tested = 0
        var dayTested = 0

        for (i in start until draws.size) {
            val history = draws.subList(0, i)
            val target = draws[i]
            val stats = Analytics.stats(history, target.day)
            if (stats.isEmpty()) continue
            val maxFreq = stats.maxOf { it.frequency }.coerceAtLeast(1)
            val rows = stats.associate { it.number to signalVector(it, maxFreq) }
            val actual = target.numbers.toSet()
            for (m in 0..5) {
                val top = rows.entries.sortedByDescending { it.value[m] }.take(5).map { it.key }
                val hits = top.count { it in actual }
                totalHits[m] += hits
                if (hits >= 2) atLeast2[m]++
                best[m] = max(best[m], hits)
                if (target.day.equals(targetDay, true)) dayHits[m] += hits
            }
            tested++
            if (target.day.equals(targetDay, true)) dayTested++
        }

        if (tested == 0) return emptyList()
        return models.indices.map { m ->
            val overall = totalHits[m].toDouble() / tested
            val dayAvg = if (dayTested == 0) overall else dayHits[m].toDouble() / dayTested
            val rate = atLeast2[m].toDouble() / tested
            val score = ((overall * 35.0) + (dayAvg * 45.0) + (rate * 20.0)).coerceIn(0.0, 100.0)
            ModelLeagueEntry(models[m], overall, dayAvg, rate, best[m], score)
        }.sortedByDescending { it.universeScore }
    }

    fun replayTimeline(draws: List<Draw>, count: Int = 18): List<ReplayPoint> {
        if (draws.size < 30) return emptyList()
        val safeCount = min(count, draws.size - 25)
        val fixedWeights = AdaptiveWeights(.22, .16, .17, .14, .17, .14)
        return (safeCount downTo 1).mapNotNull { offset ->
            val targetIndex = draws.lastIndex - (offset - 1)
            if (targetIndex < 25) return@mapNotNull null
            val target = draws[targetIndex]
            val history = draws.subList(0, targetIndex)
            val picks = AdvancedAnalytics.consensus(history, target.day, fixedWeights).take(5).map { it.number }.toSet()
            ReplayPoint(target.date, target.day, target.numbers.count { it in picks })
        }
    }

    fun dna(draws: List<Draw>, number: Int): NumberDNA? {
        if (number !in 1..90 || draws.isEmpty()) return null
        val targetDay = Analytics.nextTargetDay(draws)
        val stat = Analytics.stats(draws, targetDay).firstOrNull { it.number == number } ?: return null
        val dayCounts = days.map { day -> day.take(3).uppercase() to draws.count { it.day.equals(day, true) && number in it.numbers } }
        val pos = (0..4).map { p -> "N${p + 1}" to draws.count { it.numbers.getOrNull(p) == number } }
        val companions = Analytics.bestCompanions(draws, number, 8)
        val transitions = AdvancedAnalytics.transitions(draws, number, 8)
        val pulse = draws.takeLast(36).map { d -> d.date.takeLast(5) to if (number in d.numbers) 1.0 else 0.0 }
        return NumberDNA(number, stat.frequency, stat.recent20, stat.currentDelay, stat.averageGap, dayCounts, pos, companions, transitions, pulse)
    }

    fun galaxy(draws: List<Draw>, number: Int, limit: Int = 10): List<GalaxyNode> {
        val companions = Analytics.bestCompanions(draws, number, 30).toMap()
        val transitions = AdvancedAnalytics.transitions(draws, number, 30).associate { it.to to it.count }
        val candidates = (companions.keys + transitions.keys).filter { it != number }.distinct()
        val maxC = companions.values.maxOrNull()?.coerceAtLeast(1) ?: 1
        val maxT = transitions.values.maxOrNull()?.coerceAtLeast(1) ?: 1
        return candidates.map { n ->
            val c = companions[n] ?: 0
            val t = transitions[n] ?: 0
            val strength = ((c.toDouble() / maxC) * 65.0 + (t.toDouble() / maxT) * 35.0).coerceIn(0.0, 100.0)
            GalaxyNode(n, c, t, strength)
        }.sortedByDescending { it.strength }.take(limit)
    }

    fun smartPick(draws: List<Draw>, targetDay: String, size: Int, profile: String, seed: Int = 1): SmartPick {
        val consensus = AdvancedAnalytics.consensus(draws, targetDay)
        if (consensus.isEmpty()) return SmartPick(profile, emptyList(), 0.0, "Base insuffisante")
        val maxDelay = consensus.maxOf { it.stat.currentDelay }.coerceAtLeast(1)
        val rng = Random(draws.size * 65537 + targetDay.hashCode() * 31 + profile.hashCode() + seed * 7919)
        val scored = consensus.map { s ->
            val base = when (profile) {
                "Consensus" -> s.consensus + s.votes * 3.0
                "Prudent" -> s.consensus * .76 + s.votes * 4.0 + s.longTerm * .08
                "Dynamique" -> s.momentum * .58 + s.consensus * .32 + s.votes * 2.0
                "Contrarian" -> (s.stat.currentDelay.toDouble() / maxDelay) * 62.0 + (100.0 - s.momentum) * .22 + s.consensus * .16
                "Jour" -> s.day * .62 + s.consensus * .30 + s.votes * 1.5
                "Affinités" -> s.affinity * .62 + s.consensus * .30 + s.votes * 1.5
                "Retards" -> s.delay * .62 + s.consensus * .26 + s.cycle * .12
                else -> s.consensus
            }
            val jitter = when (profile) {
                "Prudent" -> rng.nextDouble(-.8, .8)
                "Contrarian" -> rng.nextDouble(-3.0, 3.0)
                else -> rng.nextDouble(-1.8, 1.8)
            }
            s to (base + jitter)
        }.sortedByDescending { it.second }

        val picked = mutableListOf<ConsensusSignal>()
        for ((candidate, _) in scored) {
            val decade = (candidate.number - 1) / 10
            if (picked.count { (it.number - 1) / 10 == decade } >= 2) continue
            if (size >= 5 && picked.count { it.number % 2 == candidate.number % 2 } >= 4) continue
            picked += candidate
            if (picked.size == size) break
        }
        if (picked.size < size) scored.map { it.first }.filter { c -> picked.none { it.number == c.number } }.take(size - picked.size).forEach { picked += it }
        val nums = picked.map { it.number }.sorted()
        val confidence = if (picked.isEmpty()) 0.0 else picked.map { it.consensus }.average().coerceIn(0.0, 100.0)
        val reason = when (profile) {
            "Consensus" -> "Priorité à la convergence du conseil des 6 modèles."
            "Prudent" -> "Signaux stables, historiques et votes élevés."
            "Dynamique" -> "Accent sur l'accélération récente et le momentum."
            "Contrarian" -> "Explore les retards et signaux moins évidents."
            "Jour" -> "Renforce le profil statistique spécifique au ${targetDay.uppercase()}."
            "Affinités" -> "Favorise les associations avec le contexte récent."
            "Retards" -> "Accent sur retard relatif et proximité de cycle."
            else -> "Profil adaptatif."
        }
        return SmartPick(profile, nums, confidence, reason)
    }

    fun brief(draws: List<Draw>, targetDay: String): List<UniverseBrief> {
        if (draws.isEmpty()) return emptyList()
        val out = mutableListOf<UniverseBrief>()
        val consensus = AdvancedAnalytics.consensus(draws, targetDay)
        val league = modelLeague(draws, targetDay, 48)
        val delays = Analytics.delays(draws, 5)
        val pairs = AdvancedAnalytics.topPairs(draws, 50, 5)
        val regime = AdvancedAnalytics.regime(draws)

        consensus.firstOrNull()?.let { out += UniverseBrief("Leader Universe", "${it.number.toString().padStart(2,'0')} • ${it.votes}/6 modèles • ${"%.0f".format(it.consensus)}/100", 3) }
        league.firstOrNull()?.let { out += UniverseBrief("Moteur leader", "${it.name} domine le championnat pour ${targetDay.uppercase()} • indice ${"%.0f".format(it.universeScore)}", 2) }
        delays.firstOrNull()?.let { out += UniverseBrief("Retard à surveiller", "${it.number.toString().padStart(2,'0')} • ${it.currentDelay} tirages vs moyenne ${"%.1f".format(it.averageGap)}", 2) }
        pairs.firstOrNull()?.let { out += UniverseBrief("Affinité active", "${it.first.toString().padStart(2,'0')} + ${it.second.toString().padStart(2,'0')} • ${it.recent} récentes / ${it.total} total", 1) }
        out += UniverseBrief("Régime", "${regime.label} • température ${regime.temperature}/100", 1)
        return out.take(5)
    }

    private fun signalVector(s: NumberStat, maxFreq: Int): DoubleArray {
        val delayRatio = s.currentDelay / max(1.0, s.averageGap)
        return doubleArrayOf(
            (s.momentum * 100.0).coerceIn(0.0, 100.0),
            (s.cycleScore * 100.0).coerceIn(0.0, 100.0),
            (s.pairAffinity * 100.0).coerceIn(0.0, 100.0),
            (s.dayAffinity * 100.0).coerceIn(0.0, 100.0),
            (min(1.0, delayRatio / 1.8) * 100.0).coerceIn(0.0, 100.0),
            (s.frequency.toDouble() / maxFreq * 100.0).coerceIn(0.0, 100.0)
        )
    }
}
