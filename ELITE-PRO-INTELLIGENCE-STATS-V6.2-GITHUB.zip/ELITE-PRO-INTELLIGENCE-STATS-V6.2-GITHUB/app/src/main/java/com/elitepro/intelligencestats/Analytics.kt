package com.elitepro.intelligencestats

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

object Analytics {
    private val days = listOf("lundi","mardi","mercredi","jeudi","vendredi","samedi")

    fun nextTargetDay(draws: List<Draw>): String {
        val last = draws.lastOrNull()?.day?.lowercase() ?: return "lundi"
        val idx = days.indexOf(last)
        return if (idx < 0) "lundi" else days[(idx + 1) % days.size]
    }

    fun stats(draws: List<Draw>, targetDay: String): List<NumberStat> {
        if (draws.isEmpty()) return emptyList()

        val totalFreq = IntArray(91)
        val freq20 = IntArray(91)
        val freq50 = IntArray(91)
        val dayFreq = IntArray(91)
        val dayTotal = draws.count { it.day.equals(targetDay, true) }.coerceAtLeast(1)

        draws.forEachIndexed { index, draw ->
            draw.numbers.forEach { n ->
                if (n in 1..90) {
                    totalFreq[n]++
                    if (index >= draws.size - 20) freq20[n]++
                    if (index >= draws.size - 50) freq50[n]++
                    if (draw.day.equals(targetDay, true)) dayFreq[n]++
                }
            }
        }

        val lastDraw = draws.last().numbers
        val pairCounts = pairCounts(draws)
        val maxPairWithLast = IntArray(91)
        for (n in 1..90) {
            var best = 0
            lastDraw.forEach { anchor ->
                if (anchor != n) best = max(best, pairCounts[pairKey(n, anchor)] ?: 0)
            }
            maxPairWithLast[n] = best
        }

        val maxFreq = totalFreq.maxOrNull()?.coerceAtLeast(1) ?: 1
        val max20 = freq20.maxOrNull()?.coerceAtLeast(1) ?: 1
        val max50 = freq50.maxOrNull()?.coerceAtLeast(1) ?: 1
        val maxPair = maxPairWithLast.maxOrNull()?.coerceAtLeast(1) ?: 1

        return (1..90).map { n ->
            val occurrenceIndexes = draws.mapIndexedNotNull { i, d -> if (n in d.numbers) i else null }
            val lastIndex = occurrenceIndexes.lastOrNull()
            val delay = if (lastIndex == null) draws.size else draws.lastIndex - lastIndex
            val gaps = occurrenceIndexes.zipWithNext { a, b -> b - a }
            val avgGap = if (gaps.isEmpty()) (draws.size.toDouble() / max(1, totalFreq[n])) else gaps.average()

            val frequencyScore = totalFreq[n].toDouble() / maxFreq
            val recentScore = freq20[n].toDouble() / max20
            val mediumScore = freq50[n].toDouble() / max50
            val momentum = (recentScore * 0.65 + mediumScore * 0.35)
            val delayRatio = delay / max(1.0, avgGap)
            val delayScore = min(1.0, delayRatio / 1.8)
            val dayAffinity = min(1.0, (dayFreq[n].toDouble() / dayTotal) * 18.0)
            val pairAffinity = maxPairWithLast[n].toDouble() / maxPair
            val cycleScore = 1.0 - min(1.0, abs(delayRatio - 1.0) / 1.5)

            val score = (
                frequencyScore * 0.18 +
                delayScore * 0.20 +
                momentum * 0.22 +
                dayAffinity * 0.14 +
                pairAffinity * 0.14 +
                cycleScore * 0.12
            ) * 100.0

            NumberStat(
                number = n,
                frequency = totalFreq[n],
                recent20 = freq20[n],
                recent50 = freq50[n],
                currentDelay = delay,
                averageGap = avgGap,
                dayAffinity = dayAffinity,
                pairAffinity = pairAffinity,
                momentum = momentum,
                cycleScore = cycleScore,
                score = score
            )
        }.sortedByDescending { it.score }
    }

    fun generate(draws: List<Draw>, targetDay: String, size: Int, scenario: Int = 0): List<NumberStat> {
        val ranking = stats(draws, targetDay)
        if (ranking.isEmpty()) return emptyList()
        val rng = Random(draws.size * 1009 + scenario * 7919 + targetDay.hashCode())
        val pool = ranking.take(30).map { s ->
            val jitter = rng.nextDouble(-5.0, 5.0)
            s to (s.score + jitter)
        }.sortedByDescending { it.second }

        val picked = mutableListOf<NumberStat>()
        for ((candidate, _) in pool) {
            val sameDecade = picked.count { (it.number - 1) / 10 == (candidate.number - 1) / 10 }
            val parityCount = picked.count { it.number % 2 == candidate.number % 2 }
            if (sameDecade >= 2) continue
            if (size >= 5 && parityCount >= 4) continue
            picked += candidate
            if (picked.size == size) break
        }
        if (picked.size < size) {
            ranking.filter { it.number !in picked.map { p -> p.number } }
                .take(size - picked.size)
                .forEach { picked += it }
        }
        return picked.sortedBy { it.number }
    }

    fun hot(draws: List<Draw>, count: Int = 8): List<NumberStat> =
        stats(draws, nextTargetDay(draws)).sortedByDescending { it.recent20 }.take(count)

    fun delays(draws: List<Draw>, count: Int = 8): List<NumberStat> =
        stats(draws, nextTargetDay(draws)).sortedByDescending { it.currentDelay }.take(count)

    fun bestCompanions(draws: List<Draw>, number: Int, count: Int = 6): List<Pair<Int, Int>> {
        val counts = IntArray(91)
        draws.filter { number in it.numbers }.forEach { d ->
            d.numbers.filter { it != number }.forEach { counts[it]++ }
        }
        return (1..90).filter { it != number }
            .map { it to counts[it] }
            .sortedByDescending { it.second }
            .take(count)
    }

    fun backtest(draws: List<Draw>, samples: Int = 30): BacktestResult {
        if (draws.size < 25) return BacktestResult(0,0,0.0,0,0,0)
        val start = max(20, draws.size - samples)
        var tested = 0
        var hits = 0
        var atLeast2 = 0
        var atLeast3 = 0
        var best = 0
        for (i in start until draws.size) {
            val history = draws.subList(0, i)
            val target = draws[i]
            val prediction = generate(history, target.day, 5, scenario = i).map { it.number }.toSet()
            val h = target.numbers.count { it in prediction }
            tested++
            hits += h
            if (h >= 2) atLeast2++
            if (h >= 3) atLeast3++
            best = max(best, h)
        }
        return BacktestResult(
            tested = tested,
            totalHits = hits,
            averageHits = if (tested == 0) 0.0 else hits.toDouble() / tested,
            hitAtLeast2 = atLeast2,
            hitAtLeast3 = atLeast3,
            bestHits = best
        )
    }

    private fun pairCounts(draws: List<Draw>): Map<Int, Int> {
        val map = HashMap<Int, Int>()
        draws.forEach { d ->
            val nums = d.numbers.distinct().sorted()
            for (i in nums.indices) for (j in i + 1 until nums.size) {
                val k = pairKey(nums[i], nums[j])
                map[k] = (map[k] ?: 0) + 1
            }
        }
        return map
    }

    private fun pairKey(a: Int, b: Int): Int {
        val x = min(a, b)
        val y = max(a, b)
        return x * 100 + y
    }
}
