# Élite-Pro Ultimate Stats — V5.4 Midnight Pearl Signature

Application Android de divertissement statistique 5/90, construite en Kotlin + Jetpack Compose.

## Signature 5.4
- Midnight Pearl : palette ardoise, champagne, cyan doux et surfaces plus reposantes.
- Live Intelligence : alertes analytiques locales (consensus, retards atypiques, paires actives, régime).
- Replay Lab : remonte dans l'historique et recalcule l'état **avant** un tirage cible, puis compare au résultat réel.
- Scenario Battle : Prudent / Équilibré / Explorateur comparés sur des replays historiques.
- Position Lab N1–N5 : top, jamais sortis et leader récent par position réelle de sortie.
- DNA 1–90 : fiche détaillée dans la matrice avec consensus, 6 facteurs, retard, fréquence, compagnons et transitions.
- Calendrier interactif avec saisie directe, contrôle 1–90 et anti-doublon.
- Historique complet + lundi à samedi + top/jamais sortis/retards/paires.
- Data Vault : import/export JSON et CSV.
- Elite AI local enrichi : `replay`, `battle`, `position N3`, `live`, etc.

## Données
La base embarquée contient 180 tirages jusqu'au 10/08/2026. Les tirages ajoutés/importés restent stockés localement sur le téléphone.

## Build
Le workflow GitHub Actions utilise Java 17, Android API 36 et Gradle 9.5.
Le build produit l'artifact `ELITE-PRO-MIDNIGHT-PEARL-SIGNATURE-V5.4`.
