# Élite-Pro Ultimate Stats 🔥 — Neural Studio 5.0

Application Android native Jetpack Compose de divertissement analytique autour d'une base 5/90.

## V5 Ultimate Entertainment

- Dashboard premium avec courbe des 30 derniers tirages
- Radar 6 axes du leader consensus
- Histogrammes Hot 8 et performances des modèles
- Neural Studio multi-modèles et 3 scénarios
- Matrice vivante 1–90 avec ADN statistique
- Calendrier thermique mensuel interactif
- Historique + recherche + saisie manuelle
- Data Vault : export JSON, export CSV Excel, import JSON/CSV avec fusion anti-doublons
- Assistant local Elite AI
- Base historique embarquée et fonctionnement local

## Données

La base originale est embarquée dans `app/src/main/assets/draws.json`. Les nouveaux tirages et imports sont conservés localement. L'export JSON peut sauvegarder l'ensemble de la base courante. L'export CSV utilise `;` afin d'être pratique avec les configurations Excel francophones.

## Android

- package V5 : `com.elitepro.intelligencestats.v5`
- minSdk 23
- targetSdk 36
- Jetpack Compose
- JDK 17
- Gradle 9.5 / AGP 9.3.1
