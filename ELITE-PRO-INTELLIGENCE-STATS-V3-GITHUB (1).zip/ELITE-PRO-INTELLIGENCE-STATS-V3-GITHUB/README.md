# Élite-Pro Intelligence Stats 🔥

Application Android native de divertissement et d'analyse 5/90 construite à partir de la base `perso777.xlsx`.

## Ce qui est intégré

- 179 tirages de base (02/01/2026 → 08/08/2026)
- Dashboard dynamique
- Statistiques 1–90
- Momentum 20/50
- Retards et écarts moyens
- Affinité par jour
- Associations/paires
- Indice de cycle
- Score composite à 6 facteurs
- Générateur intelligent 2/3/5
- Backtest historique
- Matrice vivante 1–90
- Saisie manuelle de nouveaux tirages
- Recalcul automatique après chaque ajout
- Assistant local Elite AI
- Fonctionnement hors connexion

## Compilation GitHub

Le workflow `.github/workflows/build-android.yml` compile un APK debug signé automatiquement par Android.

1. Mettre ce projet dans un dépôt GitHub.
2. Ouvrir **Actions**.
3. Lancer **Build Élite-Pro Android APK**.
4. Télécharger l'artifact `Elite-Pro-Intelligence-Stats-FIRE`.

L'APK debug peut être installé directement sur Android pour tester l'application.

## Stack

- Android natif
- Jetpack Compose
- AGP 9.3.1
- Gradle 9.5.0
- Kotlin 2.4.10
- Compose BOM 2026.06.00
- compileSdk 37 / targetSdk 36 / minSdk 23

## Données

La base initiale est embarquée dans `app/src/main/assets/draws.json`.
Les tirages ajoutés dans l'application sont enregistrés localement dans le téléphone.
