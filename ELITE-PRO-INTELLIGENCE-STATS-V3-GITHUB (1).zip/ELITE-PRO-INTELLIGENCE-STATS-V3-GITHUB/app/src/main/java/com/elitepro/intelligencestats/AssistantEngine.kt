package com.elitepro.intelligencestats

object AssistantEngine {
    fun answer(query: String, draws: List<Draw>): String {
        val q = query.trim().lowercase()
        if (q.isBlank()) return "Écris une demande : « analyse 27 », « top retards », « compagnons 46 » ou « génère 5 »."

        val number = Regex("""\b([1-9]|[1-8][0-9]|90)\b""").find(q)?.value?.toIntOrNull()
        val targetDay = Analytics.nextTargetDay(draws)

        if ("retard" in q) {
            return Analytics.delays(draws, 10).joinToString(
                prefix = "Top retards actuels :\n",
                separator = "\n"
            ) { "• ${it.number} — ${it.currentDelay} tirage(s), moyenne ${"%.1f".format(it.averageGap)}" }
        }

        if ("chaud" in q || "fréquence" in q || "frequence" in q) {
            return Analytics.hot(draws, 10).joinToString(
                prefix = "Numéros les plus actifs sur les 20 derniers tirages :\n",
                separator = "\n"
            ) { "• ${it.number} — ${it.recent20} sortie(s)" }
        }

        if (("compagnon" in q || "paire" in q) && number != null) {
            return Analytics.bestCompanions(draws, number, 8).joinToString(
                prefix = "Compagnons historiques de $number :\n",
                separator = "\n"
            ) { "• ${it.first} — ${it.second} association(s)" }
        }

        if ("génère" in q || "genere" in q || "combinaison" in q || "scenario" in q) {
            val size = when {
                Regex("""\b2\b""").containsMatchIn(q) -> 2
                Regex("""\b3\b""").containsMatchIn(q) -> 3
                else -> 5
            }
            val picks = Analytics.generate(draws, targetDay, size, scenario = q.hashCode())
            return "Scénario intelligent pour $targetDay : ${picks.joinToString(" • ") { it.number.toString().padStart(2,'0') }}\n" +
                    "Scores : ${picks.joinToString(" | ") { "${it.number}:${"%.0f".format(it.score)}" }}"
        }

        if (number != null) {
            val stat = Analytics.stats(draws, targetDay).firstOrNull { it.number == number }
                ?: return "Numéro introuvable."
            val companions = Analytics.bestCompanions(draws, number, 5)
            return buildString {
                append("Analyse du $number\n")
                append("• Fréquence totale : ${stat.frequency}\n")
                append("• 20 derniers : ${stat.recent20}\n")
                append("• Retard actuel : ${stat.currentDelay}\n")
                append("• Écart moyen : ${"%.1f".format(stat.averageGap)}\n")
                append("• Score composite : ${"%.1f".format(stat.score)}/100\n")
                append("• Compagnons : ${companions.joinToString { "${it.first}(${it.second})" }}")
            }
        }

        return "Je peux analyser un numéro, les retards, les fréquences, les compagnons et générer des scénarios 2/3/5. Exemple : « analyse 46 »."
    }
}
