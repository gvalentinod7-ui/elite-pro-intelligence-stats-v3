package com.elitepro.intelligencestats

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject

class DrawRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("elite_pro_stats", Context.MODE_PRIVATE)
    val draws = mutableStateListOf<Draw>()

    init {
        reload()
    }

    fun reload() {
        draws.clear()
        draws.addAll(loadBaseDraws())
        draws.addAll(loadUserDraws())
        draws.sortBy { it.date }
    }

    private fun loadBaseDraws(): List<Draw> {
        val raw = context.assets.open("draws.json").bufferedReader().use { it.readText() }
        return parseDrawArray(JSONArray(raw), "base")
    }

    private fun loadUserDraws(): List<Draw> {
        val raw = prefs.getString("user_draws", "[]") ?: "[]"
        return runCatching { parseDrawArray(JSONArray(raw), "user") }.getOrDefault(emptyList())
    }

    private fun parseDrawArray(array: JSONArray, fallbackSource: String): List<Draw> {
        val out = ArrayList<Draw>(array.length())
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            val nums = o.getJSONArray("numbers")
            val values = (0 until nums.length()).map { nums.getInt(it) }
            out += Draw(
                date = o.getString("date"),
                day = o.getString("day"),
                numbers = values,
                source = o.optString("source", fallbackSource)
            )
        }
        return out
    }

    fun addDraw(draw: Draw): Result<Unit> {
        if (draw.numbers.size != 5) return Result.failure(IllegalArgumentException("5 numéros requis"))
        if (draw.numbers.distinct().size != 5) return Result.failure(IllegalArgumentException("Les numéros doivent être différents"))
        if (draw.numbers.any { it !in 1..90 }) return Result.failure(IllegalArgumentException("Les numéros doivent être entre 1 et 90"))
        if (draws.any { it.date == draw.date }) return Result.failure(IllegalArgumentException("Un tirage existe déjà à cette date"))

        val user = loadUserDraws().toMutableList()
        user += draw.copy(source = "user")
        saveUserDraws(user)
        reload()
        return Result.success(Unit)
    }

    fun clearUserDraws() {
        prefs.edit().remove("user_draws").apply()
        reload()
    }

    private fun saveUserDraws(items: List<Draw>) {
        val array = JSONArray()
        items.forEach { d ->
            val o = JSONObject()
            o.put("date", d.date)
            o.put("day", d.day)
            o.put("source", "user")
            val nums = JSONArray()
            d.numbers.forEach { nums.put(it) }
            o.put("numbers", nums)
            array.put(o)
        }
        prefs.edit().putString("user_draws", array.toString()).apply()
    }
}
