package com.elitepro.intelligencestats

data class Draw(
    val date: String,
    val day: String,
    val numbers: List<Int>,
    val source: String = "base"
)

data class NumberStat(
    val number: Int,
    val frequency: Int,
    val recent20: Int,
    val recent50: Int,
    val currentDelay: Int,
    val averageGap: Double,
    val dayAffinity: Double,
    val pairAffinity: Double,
    val momentum: Double,
    val cycleScore: Double,
    val score: Double
)

data class BacktestResult(
    val tested: Int,
    val totalHits: Int,
    val averageHits: Double,
    val hitAtLeast2: Int,
    val hitAtLeast3: Int,
    val bestHits: Int
)
