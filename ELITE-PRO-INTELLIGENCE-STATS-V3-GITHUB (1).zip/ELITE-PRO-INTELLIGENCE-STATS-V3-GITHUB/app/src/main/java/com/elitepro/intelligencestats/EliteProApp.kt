package com.elitepro.intelligencestats

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.format.DateTimeFormatter

private val Bg = Color(0xFF07090D)
private val Surface = Color(0xFF10141D)
private val Surface2 = Color(0xFF171C27)
private val Orange = Color(0xFFFF7A00)
private val Gold = Color(0xFFFFC857)
private val Red = Color(0xFFFF3D3D)
private val Green = Color(0xFF33D17A)
private val Text = Color(0xFFF5F7FB)
private val Muted = Color(0xFF9AA4B2)

private enum class Tab(val title: String, val glyph: String) {
    HOME("Accueil","⌂"),
    LAB("Intelligence","⚡"),
    MATRIX("Matrice","▦"),
    HISTORY("Tirages","◷"),
    ASSISTANT("Assistant","AI")
}

@Composable
fun EliteProApp(context: Context) {
    val repository = remember { DrawRepository(context) }
    val draws = repository.draws
    var tab by remember { mutableStateOf(Tab.HOME) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Orange,
            secondary = Gold,
            background = Bg,
            surface = Surface,
            onPrimary = Color.Black,
            onBackground = Text,
            onSurface = Text
        )
    ) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                Surface(color = Bg) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🔥", fontSize = 30.sp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Élite-Pro Intelligence Stats", color = Text, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                            Text("${draws.size} tirages • moteur local vivant", color = Muted, fontSize = 12.sp)
                        }
                        Box(
                            modifier = Modifier.background(Green.copy(alpha=.14f), CircleShape)
                                .border(1.dp, Green.copy(alpha=.4f), CircleShape)
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) { Text("LIVE", color = Green, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                    }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0B0E14), tonalElevation = 8.dp) {
                    Tab.entries.forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = { Text(item.glyph, fontWeight = FontWeight.ExtraBold) },
                            label = { Text(item.title, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Orange,
                                selectedTextColor = Orange,
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted,
                                indicatorColor = Orange.copy(alpha=.12f)
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (tab) {
                    Tab.HOME -> HomeScreen(draws)
                    Tab.LAB -> LabScreen(draws)
                    Tab.MATRIX -> MatrixScreen(draws)
                    Tab.HISTORY -> HistoryScreen(draws, repository)
                    Tab.ASSISTANT -> AssistantScreen(draws)
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(draws: List<Draw>) {
    val targetDay = remember(draws.size) { Analytics.nextTargetDay(draws) }
    val stats = remember(draws.size, targetDay) { Analytics.stats(draws, targetDay) }
    val last = draws.lastOrNull()
    val hot = remember(draws.size) { Analytics.hot(draws, 6) }
    val delays = remember(draws.size) { Analytics.delays(draws, 6) }
    var scenario by remember(draws.size) { mutableStateOf<List<NumberStat>>(emptyList()) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(
            Modifier.fillMaxWidth()
                .background(Brush.linearGradient(listOf(Color(0xFF2B1200), Color(0xFF111722))), RoundedCornerShape(26.dp))
                .border(1.dp, Orange.copy(alpha=.35f), RoundedCornerShape(26.dp))
                .padding(20.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("INTELLIGENCE ENGINE 3.0", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("Une base qui apprend à chaque nouveau tirage.", color = Text, fontSize = 26.sp, lineHeight = 30.sp, fontWeight = FontWeight.Black)
                Text("6 facteurs • cycles • momentum • affinités • retards • profil du jour", color = Muted, fontSize = 13.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Prochaine cible : ", color = Muted)
                    Text(targetDay.uppercase(), color = Orange, fontWeight = FontWeight.Bold)
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Tirages", draws.size.toString(), Modifier.weight(1f))
            MetricCard("Base 1–90", if (stats.size == 90) "OK" else "${stats.size}", Modifier.weight(1f))
            MetricCard("Top score", stats.firstOrNull()?.number?.toString() ?: "—", Modifier.weight(1f))
        }

        if (last != null) {
            SectionCard("Dernier tirage • ${last.date}") {
                NumberBalls(last.numbers)
            }
        }

        SectionCard("Radar chaud • 20 derniers") {
            MiniRank(hot, mode = "hot")
        }

        SectionCard("Retards les plus élevés") {
            MiniRank(delays, mode = "delay")
        }

        Button(
            onClick = { scenario = Analytics.generate(draws, targetDay, 5, scenario = (scenario.sumOf { it.number } + 1)) },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Orange),
            shape = RoundedCornerShape(18.dp)
        ) {
            Text("🔥 GÉNÉRER UN SCÉNARIO 5", fontWeight = FontWeight.ExtraBold)
        }

        if (scenario.isNotEmpty()) {
            SectionCard("Scénario intelligent") {
                NumberBalls(scenario.map { it.number })
                Spacer(Modifier.height(10.dp))
                scenario.forEach { ScoreLine(it) }
            }
        }

        Text(
            "Élite-Pro classe des scénarios à partir de l'historique. Les scores sont analytiques et destinés au divertissement.",
            color = Muted, fontSize = 11.sp, lineHeight = 15.sp
        )
    }
}

@Composable
private fun LabScreen(draws: List<Draw>) {
    val days = listOf("lundi","mardi","mercredi","jeudi","vendredi","samedi")
    var targetDay by remember(draws.size) { mutableStateOf(Analytics.nextTargetDay(draws)) }
    var size by remember { mutableIntStateOf(5) }
    var scenarioIndex by remember { mutableIntStateOf(1) }
    var picks by remember { mutableStateOf<List<NumberStat>>(emptyList()) }
    var backtest by remember { mutableStateOf<BacktestResult?>(null) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Intelligence Lab", color = Text, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Text("Le moteur combine six signaux puis diversifie les scénarios.", color = Muted)

        SectionCard("Jour cible") {
            FlowRowCompat {
                days.forEach { d ->
                    FilterChip(
                        selected = targetDay == d,
                        onClick = { targetDay = d },
                        label = { Text(d.take(3).uppercase()) }
                    )
                }
            }
        }

        SectionCard("Taille du scénario") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(2,3,5).forEach { s ->
                    FilterChip(
                        selected = size == s,
                        onClick = { size = s },
                        label = { Text("$s numéros") }
                    )
                }
            }
        }

        Button(
            onClick = {
                picks = Analytics.generate(draws, targetDay, size, scenarioIndex++)
            },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Orange),
            shape = RoundedCornerShape(18.dp)
        ) { Text("⚡ CALCULER LE SCÉNARIO", fontWeight = FontWeight.ExtraBold) }

        if (picks.isNotEmpty()) {
            SectionCard("Résultat • $targetDay") {
                NumberBalls(picks.map { it.number })
                Spacer(Modifier.height(14.dp))
                picks.forEach { ScoreLine(it) }
            }
        }

        SectionCard("Auto-Learn • backtest") {
            Text(
                "Le test reconstruit chaque situation avec uniquement les tirages antérieurs, puis mesure les correspondances du top 5.",
                color = Muted, fontSize = 13.sp
            )
            Spacer(Modifier.height(10.dp))
            OutlinedButton(
                onClick = { backtest = Analytics.backtest(draws, 30) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("LANCER LE BACKTEST 30") }

            backtest?.let { b ->
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetricCard("Moy. hits", "%.2f".format(b.averageHits), Modifier.weight(1f))
                    MetricCard("≥2 hits", b.hitAtLeast2.toString(), Modifier.weight(1f))
                    MetricCard("Best", b.bestHits.toString(), Modifier.weight(1f))
                }
            }
        }

        SectionCard("Architecture du score") {
            val factors = listOf(
                "Momentum" to .22f, "Retard" to .20f, "Fréquence" to .18f,
                "Jour" to .14f, "Paires" to .14f, "Cycle" to .12f
            )
            factors.forEach { (name, weight) ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(name, color = Text, modifier = Modifier.width(90.dp), fontSize = 12.sp)
                    LinearProgressIndicator(
                        progress = { weight },
                        modifier = Modifier.weight(1f).height(8.dp),
                        color = Orange,
                        trackColor = Surface2
                    )
                    Text("${(weight*100).toInt()}%", color = Gold, modifier = Modifier.width(44.dp), textAlign = TextAlign.End, fontSize = 12.sp)
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun MatrixScreen(draws: List<Draw>) {
    val targetDay = remember(draws.size) { Analytics.nextTargetDay(draws) }
    val stats = remember(draws.size, targetDay) { Analytics.stats(draws, targetDay) }
    val byNumber = remember(stats) { stats.associateBy { it.number } }
    var selected by remember { mutableIntStateOf(stats.firstOrNull()?.number ?: 1) }
    val s = byNumber[selected]

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Text("Matrice vivante 1–90", color = Text, fontSize = 25.sp, fontWeight = FontWeight.Black)
        Text("Intensité = score composite pour $targetDay", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(10),
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(5.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            gridItems((1..90).toList()) { n ->
                val st = byNumber[n]
                val intensity = ((st?.score ?: 0.0) / 100.0).coerceIn(0.0,1.0).toFloat()
                val bg = Color(
                    red = 0.18f + 0.75f * intensity,
                    green = 0.12f + 0.25f * intensity,
                    blue = 0.08f,
                    alpha = 1f
                )
                Box(
                    modifier = Modifier.aspectRatio(1f)
                        .background(bg, RoundedCornerShape(8.dp))
                        .border(if (selected == n) 2.dp else 1.dp, if (selected == n) Gold else Color.White.copy(alpha=.08f), RoundedCornerShape(8.dp))
                        .clickable { selected = n },
                    contentAlignment = Alignment.Center
                ) {
                    Text(n.toString(), color = Text, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }

        if (s != null) {
            Spacer(Modifier.height(12.dp))
            SectionCard("Focus $selected") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetricCard("Score", "%.0f".format(s.score), Modifier.weight(1f))
                    MetricCard("Retard", s.currentDelay.toString(), Modifier.weight(1f))
                    MetricCard("20 tirages", s.recent20.toString(), Modifier.weight(1f))
                    MetricCard("Total", s.frequency.toString(), Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun HistoryScreen(draws: List<Draw>, repository: DrawRepository) {
    var date by remember { mutableStateOf(LocalDate.now().format(DateTimeFormatter.ISO_DATE)) }
    var nums by remember { mutableStateOf(List(5) { "" }) }
    var message by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Text("Tirages & mise à jour", color = Text, fontSize = 25.sp, fontWeight = FontWeight.Black)
        Text("Chaque ajout recalcule immédiatement tout le moteur.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))

        SectionCard("Ajouter un tirage") {
            OutlinedTextField(
                value = date,
                onValueChange = { date = it },
                label = { Text("Date AAAA-MM-JJ") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                nums.forEachIndexed { i, v ->
                    OutlinedTextField(
                        value = v,
                        onValueChange = { new ->
                            nums = nums.toMutableList().also { it[i] = new.filter(Char::isDigit).take(2) }
                        },
                        label = { Text("N${i+1}") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    val parsed = nums.mapNotNull { it.toIntOrNull() }
                    val localDate = runCatching { LocalDate.parse(date) }.getOrNull()
                    if (localDate == null) {
                        message = "Date invalide."
                    } else if (parsed.size != 5) {
                        message = "Saisis les 5 numéros."
                    } else {
                        val day = when (localDate.dayOfWeek.value) {
                            1 -> "lundi"; 2 -> "mardi"; 3 -> "mercredi"; 4 -> "jeudi"
                            5 -> "vendredi"; 6 -> "samedi"; else -> "dimanche"
                        }
                        val result = repository.addDraw(Draw(date, day, parsed, "user"))
                        message = result.fold(
                            onSuccess = {
                                nums = List(5) { "" }
                                "🔥 Tirage ajouté. Intelligence recalculée."
                            },
                            onFailure = { it.message ?: "Erreur" }
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Orange)
            ) { Text("AJOUTER & RECALCULER", fontWeight = FontWeight.Bold) }

            if (message.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(message, color = if ("ajouté" in message) Green else Red, fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(12.dp))
        Text("Historique récent", color = Text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(draws.asReversed().take(40), key = { it.date }) { d ->
                Row(
                    Modifier.fillMaxWidth().background(Surface, RoundedCornerShape(14.dp)).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.width(92.dp)) {
                        Text(d.date, color = Text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(d.day, color = Muted, fontSize = 11.sp)
                    }
                    Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        d.numbers.forEach { Ball(it, 34.dp) }
                    }
                    if (d.source == "user") Text("NEW", color = Green, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun AssistantScreen(draws: List<Draw>) {
    var query by remember { mutableStateOf("") }
    var response by remember { mutableStateOf("Je suis Elite AI 🔥. Interroge directement ta base.") }

    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Elite AI", color = Text, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Text("Assistant local • aucune connexion requise", color = Muted)

        Box(
            Modifier.fillMaxWidth().weight(1f)
                .background(Surface, RoundedCornerShape(22.dp))
                .border(1.dp, Orange.copy(alpha=.18f), RoundedCornerShape(22.dp))
                .padding(18.dp)
        ) {
            Text(response, color = Text, lineHeight = 22.sp)
        }

        Column(
            Modifier.fillMaxWidth().background(Surface, RoundedCornerShape(18.dp)).padding(12.dp)
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Ex. analyse 27, top retards…") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    response = AssistantEngine.answer(query, draws)
                    query = ""
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Orange)
            ) { Text("DEMANDER À ELITE AI 🔥", fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier.background(Surface, RoundedCornerShape(14.dp)).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Black)
        Text(label, color = Muted, fontSize = 10.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth()
            .background(Surface, RoundedCornerShape(20.dp))
            .border(1.dp, Color.White.copy(alpha=.06f), RoundedCornerShape(20.dp))
            .padding(16.dp)
    ) {
        Text(title, color = Text, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
        Spacer(Modifier.height(12.dp))
        content()
    }
}

@Composable
private fun NumberBalls(numbers: List<Int>) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        numbers.forEach { Ball(it, 48.dp) }
    }
}

@Composable
private fun Ball(number: Int, size: androidx.compose.ui.unit.Dp) {
    Box(
        Modifier.size(size)
            .background(Brush.radialGradient(listOf(Gold, Orange, Color(0xFFB83C00))), CircleShape)
            .border(1.dp, Color.White.copy(alpha=.22f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(number.toString().padStart(2, '0'), color = Color.Black, fontWeight = FontWeight.Black, fontSize = if (size > 40.dp) 15.sp else 11.sp)
    }
}

@Composable
private fun MiniRank(items: List<NumberStat>, mode: String) {
    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        items.forEachIndexed { index, s ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("#${index+1}", color = Muted, modifier = Modifier.width(32.dp), fontSize = 11.sp)
                Ball(s.number, 32.dp)
                Spacer(Modifier.width(10.dp))
                LinearProgressIndicator(
                    progress = {
                        if (mode == "delay") (s.currentDelay / 25f).coerceIn(0f,1f)
                        else (s.recent20 / 6f).coerceIn(0f,1f)
                    },
                    modifier = Modifier.weight(1f).height(8.dp),
                    color = if (mode == "delay") Gold else Orange,
                    trackColor = Surface2
                )
                Spacer(Modifier.width(8.dp))
                Text(if (mode == "delay") "${s.currentDelay}" else "${s.recent20}x", color = Text, fontSize = 12.sp, modifier = Modifier.width(34.dp), textAlign = TextAlign.End)
            }
        }
    }
}

@Composable
private fun ScoreLine(s: NumberStat) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Text(s.number.toString().padStart(2,'0'), color = Gold, fontWeight = FontWeight.Black, modifier = Modifier.width(36.dp))
        LinearProgressIndicator(
            progress = { (s.score / 100.0).toFloat().coerceIn(0f,1f) },
            modifier = Modifier.weight(1f).height(8.dp),
            color = Orange,
            trackColor = Surface2
        )
        Text("%.0f".format(s.score), color = Text, modifier = Modifier.width(42.dp), textAlign = TextAlign.End)
    }
    Spacer(Modifier.height(7.dp))
}

@Composable
private fun FlowRowCompat(content: @Composable RowScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), content = content)
    }
}
