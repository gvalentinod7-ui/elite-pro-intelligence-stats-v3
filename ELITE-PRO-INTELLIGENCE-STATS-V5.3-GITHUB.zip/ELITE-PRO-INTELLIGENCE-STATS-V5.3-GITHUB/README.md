# Élite-Pro Ultimate Stats V5.3 — Midnight Pearl Edition

Version Android native Jetpack Compose centrée sur le confort visuel, la lisibilité et une hiérarchie analytique plus claire.

## Nouveautés V5.3
- Palette Midnight Pearl plus claire : ardoise, bleu brume, champagne et cyan doux
- Fond en dégradé premium, moins noir et moins fatigant
- Matrice 1–90 repensée avec 5 niveaux visuels : Discret, Stable, Actif, Fort, Élite
- Numéro sélectionné en finition nacrée claire, sans effet feu
- Fiche ADN lisible sous la matrice : score, retard, fréquence, récent 20 et 6 barres de signaux
- Compagnons et transitions regroupés dans une carte Connexions
- Radar compact retiré de la fiche Matrice au profit de barres comparables
- Cartes et métriques plus lumineuses, contrastes renforcés
- Boules premium satinées conservées, avec rendu champagne/perle plus doux
- Calendrier, historique complet, vues lundi–samedi, TOP 10, jamais sortis, retards, paires dominantes
- Ajout direct depuis le calendrier avec validation 1–90 et anti-doublon
- Import/export JSON et CSV conservés
- Studio multi-modèles, scénarios, backtests et Elite AI conservés
- Base embarquée : 180 tirages

Package de test : `com.elitepro.intelligencestats.v53.dev`
